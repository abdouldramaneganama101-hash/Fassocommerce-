package com.fassocommerce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdminActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int PICK_IMAGE = 1001;
    private Uri selectedImage;
    private ImageView preview;
    private EditText nameInput;
    private EditText priceInput;
    private EditText stockInput;
    private EditText descriptionInput;
    private int editingIndex = -1;
    private LinearLayout productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 40);
        main.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("ADMINISTRATION");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(GREEN);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        TextView info = new TextView(this);
        info.setText("Gestion privée de Fasso Commerce");
        info.setTextSize(17);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 10, 0, 25);
        main.addView(info);

        Button add = addButton(main, "➕  Ajouter un produit");
        add.setOnClickListener(v -> showProductForm(-1));

        Button photos = addButton(main, "🖼️  Ajouter un produit avec une photo");
        photos.setOnClickListener(v -> showProductForm(-1));

        TextView listTitle = new TextView(this);
        listTitle.setText("Produits enregistrés");
        listTitle.setTextSize(22);
        listTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        listTitle.setTextColor(GREEN);
        listTitle.setPadding(0, 20, 0, 10);
        main.addView(listTitle);

        productList = new LinearLayout(this);
        productList.setOrientation(LinearLayout.VERTICAL);
        main.addView(productList);

        TextView security = new TextView(this);
        security.setText("\nCette administration est une version locale de test. Une authentification serveur renforcée sera nécessaire avant la mise en production.");
        security.setTextSize(14);
        security.setGravity(Gravity.CENTER);
        security.setPadding(0, 20, 0, 20);
        main.addView(security);

        Button back = new Button(this);
        back.setText("← Retour à la boutique");
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(GREEN);
        main.addView(back, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        back.setOnClickListener(v -> finish());

        scrollView.addView(main);
        setContentView(scrollView);
        refreshProductList();
    }

    private Button addButton(LinearLayout main, String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setTextColor(Color.BLACK);
        button.setBackgroundColor(Color.rgb(245, 245, 245));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 10);
        main.addView(button, params);
        return button;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(17);
        e.setSingleLine(false);
        e.setPadding(14, 10, 14, 10);
        return e;
    }

    private void showProductForm(int index) {
        editingIndex = index;
        selectedImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(5, 5, 5, 5);

        nameInput = field("Nom du produit");
        priceInput = field("Prix");
        stockInput = field("Stock");
        descriptionInput = field("Description du produit");
        form.addView(nameInput);
        form.addView(priceInput);
        form.addView(stockInput);
        form.addView(descriptionInput);

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        form.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 230));

        Button choose = new Button(this);
        choose.setText("📷 Choisir une photo");
        choose.setOnClickListener(v -> chooseProductPhoto());
        form.addView(choose);

        if (index >= 0) {
            try {
                JSONObject p = ProductStore.getProducts(this).getJSONObject(index);
                nameInput.setText(p.optString("name", ""));
                priceInput.setText(p.optString("price", ""));
                stockInput.setText(p.optString("stock", ""));
                descriptionInput.setText(p.optString("description", ""));
                String uri = p.optString("imageUri", "");
                if (!uri.isEmpty()) {
                    selectedImage = Uri.parse(uri);
                    preview.setImageURI(selectedImage);
                }
            } catch (Exception ignored) {}
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(index >= 0 ? "Modifier le produit" : "Ajouter un produit")
                .setView(form)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String price = priceInput.getText().toString().trim();
            String stock = stockInput.getText().toString().trim();
            String description = descriptionInput.getText().toString().trim();
            if (name.isEmpty()) {
                nameInput.setError("Nom obligatoire");
                return;
            }
            if (selectedImage == null) {
                Toast.makeText(this, "Choisis une photo du produit.", Toast.LENGTH_LONG).show();
                return;
            }
            try {
                if (editingIndex >= 0) {
                    ProductStore.updateProduct(this, editingIndex, name, price, stock, description, selectedImage.toString());
                    Toast.makeText(this, "Produit modifié.", Toast.LENGTH_SHORT).show();
                } else {
                    ProductStore.addProduct(this, name, price, stock, description, selectedImage.toString());
                    Toast.makeText(this, "Produit ajouté à la boutique.", Toast.LENGTH_LONG).show();
                }
                dialog.dismiss();
                refreshProductList();
            } catch (Exception e) {
                Toast.makeText(this, "Impossible d'enregistrer le produit.", Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
    }

    private void chooseProductPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImage = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedImage, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            if (preview != null) preview.setImageURI(selectedImage);
            Toast.makeText(this, "Photo sélectionnée. Appuie maintenant sur Enregistrer.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshProductList() {
        if (productList == null) return;
        productList.removeAllViews();
        JSONArray products = ProductStore.getProducts(this);
        if (products.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Aucun produit enregistré.");
            empty.setTextSize(16);
            empty.setPadding(5, 10, 5, 20);
            productList.addView(empty);
            return;
        }
        for (int i = 0; i < products.length(); i++) {
            final int index = i;
            try {
                JSONObject p = products.getJSONObject(i);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(12, 12, 12, 12);
                row.setBackgroundColor(Color.rgb(247, 249, 248));
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.setMargins(0, 0, 0, 12);

                String image = p.optString("imageUri", "");
                if (!image.isEmpty()) {
                    ImageView img = new ImageView(this);
                    img.setAdjustViewBounds(true);
                    img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    img.setImageURI(Uri.parse(image));
                    row.addView(img, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 180));
                }
                TextView name = new TextView(this);
                name.setText(p.optString("name", "Produit") + " — " + p.optString("price", "Prix non défini"));
                name.setTextSize(18);
                name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                row.addView(name);
                TextView stock = new TextView(this);
                stock.setText("Stock : " + p.optString("stock", "0"));
                row.addView(stock);

                LinearLayout actions = new LinearLayout(this);
                Button edit = new Button(this);
                edit.setText("✏️ Modifier");
                edit.setOnClickListener(v -> showProductForm(index));
                Button delete = new Button(this);
                delete.setText("🗑️ Supprimer");
                delete.setOnClickListener(v -> confirmDelete(index));
                actions.addView(edit, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                actions.addView(delete, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                row.addView(actions);
                productList.addView(row, rp);
            } catch (Exception ignored) {}
        }
    }

    private void confirmDelete(int index) {
        new AlertDialog.Builder(this)
                .setTitle("Supprimer le produit ?")
                .setMessage("Le produit sera retiré de la boutique sur ce téléphone.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Supprimer", (d, w) -> {
                    ProductStore.deleteProduct(this, index);
                    refreshProductList();
                    Toast.makeText(this, "Produit supprimé.", Toast.LENGTH_SHORT).show();
                }).show();
    }
}
