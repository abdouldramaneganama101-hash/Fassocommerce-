package com.fassocommerce;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ProductStore {
    private static final String PREFS = "fasso_products";
    private static final String KEY = "items";

    private ProductStore() {}

    public static JSONArray getProducts(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY, "[]");
        try {
            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void saveProducts(Context context, JSONArray products) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, products.toString())
                .apply();
    }

    public static void addProduct(Context context, String name, String price, String stock, String description, String imageUri) throws Exception {
        JSONArray products = getProducts(context);
        JSONObject item = new JSONObject();
        item.put("id", System.currentTimeMillis());
        item.put("name", name);
        item.put("price", price);
        item.put("stock", stock);
        item.put("description", description);
        item.put("imageUri", imageUri == null ? "" : imageUri);
        products.put(item);
        saveProducts(context, products);
    }

    public static void updateProduct(Context context, int index, String name, String price, String stock, String description, String imageUri) throws Exception {
        JSONArray products = getProducts(context);
        if (index < 0 || index >= products.length()) return;
        JSONObject item = products.getJSONObject(index);
        item.put("name", name);
        item.put("price", price);
        item.put("stock", stock);
        item.put("description", description);
        item.put("imageUri", imageUri == null ? "" : imageUri);
        saveProducts(context, products);
    }

    public static void deleteProduct(Context context, int index) {
        JSONArray products = getProducts(context);
        if (index < 0 || index >= products.length()) return;
        products.remove(index);
        saveProducts(context, products);
    }
}
