package com.fassocommerce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int DARK = Color.rgb(25, 35, 45);
    private static final int LIGHT = Color.rgb(247, 249, 248);
    private LinearLayout productContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (productContainer != null) loadProducts();
    }

    private void buildScreen() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.WHITE);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(22, 18, 22, 35);
        main.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 10, 12, 10);
        header.setBackgroundColor(GREEN);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, new LinearLayout.LayoutParams(95, 70));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("Fasso\nCommerce");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(19);
        headerTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(headerTitle, new LinearLayout.LayoutParams(0, 70, 1));

        TextView searchIcon = new TextView(this);
        searchIcon.setText("⌕");
        searchIcon.setTextColor(Color.WHITE);
        searchIcon.setTextSize(34);
        searchIcon.setGravity(Gravity.CENTER);
        header.addView(searchIcon, new LinearLayout.LayoutParams(55, 70));

        TextView menuIcon = new TextView(this);
        menuIcon.setText("⋮");
        menuIcon.setTextColor(Color.WHITE);
        menuIcon.setTextSize(32);
        menuIcon.setGravity(Gravity.CENTER);
        menuIcon.setContentDescription("Menu");
        menuIcon.setClickable(true);
        menuIcon.setFocusable(true);
        menuIcon.setOnClickListener(v -> showMenu(menuIcon));
        header.addView(menuIcon, new LinearLayout.LayoutParams(45, 70));
        main.addView(header);

        TextView welcome = text("Accueil", 34, DARK, true);
        welcome.setPadding(8, 28, 8, 5);
        main.addView(welcome);

        TextView subtitle = text("Bienvenue chez Fasso Commerce", 20, Color.DKGRAY, false);
        subtitle.setPadding(8, 0, 8, 20);
        main.addView(subtitle);

        EditText search = new EditText(this);
        search.setHint("Rechercher un produit");
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setPadding(18, 8, 18, 8);
        main.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView advertising = text("PUBLICITÉ\n\nDécouvrez ici vos prochaines publicités et photos de produits", 19, Color.WHITE, true);
        advertising.setGravity(Gravity.CENTER);
        advertising.setPadding(15, 38, 15, 38);
        advertising.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams adParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        adParams.setMargins(0, 22, 0, 25);
        main.addView(advertising, adParams);

        TextView productsTitle = text("Nos produits", 30, DARK, true);
        productsTitle.setPadding(8, 5, 8, 4);
        main.addView(productsTitle);

        TextView productsSubtitle = text("Découvrez tous nos produits", 18, Color.DKGRAY, false);
        productsSubtitle.setPadding(8, 0, 8, 18);
        main.addView(productsSubtitle);

        productContainer = new LinearLayout(this);
        productContainer.setOrientation(LinearLayout.VERTICAL);
        main.addView(productContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(0, 10, 0, 5);
        addNavigationItem(navigation, "⌂", "Accueil", true);
        addNavigationItem(navigation, "▣", "Nos produits", false);
        addNavigationItem(navigation, "🛒", "Panier", false);
        addNavigationItem(navigation, "●", "Compte", false);
        main.addView(navigation);

        scrollView.addView(main);
        setContentView(scrollView);
        loadProducts();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void loadProducts() {
        if (productContainer == null) return;
        productContainer.removeAllViews();
        JSONArray products = ProductStore.getProducts(this);
        if (products.length() == 0) {
            LinearLayout emptyBox = new LinearLayout(this);
            emptyBox.setOrientation(LinearLayout.VERTICAL);
            emptyBox.setGravity(Gravity.CENTER);
            emptyBox.setPadding(20, 55, 20, 55);
            emptyBox.setBackgroundColor(LIGHT);

            TextView boxIcon = text("▣", 62, GREEN, false);
            boxIcon.setGravity(Gravity.CENTER);
            emptyBox.addView(boxIcon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 90));
            TextView emptyTitle = text("Aucun produit pour le moment", 23, DARK, true);
            emptyTitle.setGravity(Gravity.CENTER);
            emptyTitle.setPadding(0, 10, 0, 10);
            emptyBox.addView(emptyTitle);
            TextView emptyText = text("Les produits seront ajoutés avec leurs photos, prix et descriptions.", 17, Color.DKGRAY, false);
            emptyText.setGravity(Gravity.CENTER);
            emptyBox.addView(emptyText);
            productContainer.addView(emptyBox);
            return;
        }

        for (int i = 0; i < products.length(); i++) {
            try {
                JSONObject p = products.getJSONObject(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(12, 12, 12, 16);
                card.setBackgroundColor(LIGHT);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cp.setMargins(0, 0, 0, 14);

                String imageUri = p.optString("imageUri", "");
                if (!imageUri.isEmpty()) {
                    ImageView image = new ImageView(this);
                    image.setAdjustViewBounds(true);
                    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    try { image.setImageURI(Uri.parse(imageUri)); } catch (Exception ignored) {}
                    card.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 240));
                }

                TextView name = text(p.optString("name", "Produit"), 22, DARK, true);
                name.setPadding(6, 10, 6, 4);
                card.addView(name);
                TextView price = text("Prix : " + p.optString("price", "À préciser"), 18, GREEN, true);
                price.setPadding(6, 0, 6, 4);
                card.addView(price);
                TextView stock = text("Stock : " + p.optString("stock", "0"), 16, Color.DKGRAY, false);
                stock.setPadding(6, 0, 6, 4);
                card.addView(stock);
                TextView description = text(p.optString("description", ""), 16, Color.DKGRAY, false);
                description.setPadding(6, 0, 6, 4);
                card.addView(description);
                productContainer.addView(card, cp);
            } catch (Exception ignored) {}
        }
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("🔐 Administration");
        popup.getMenu().add("Fermer");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle().toString().contains("Administration")) {
                openAdminProtected();
                return true;
            }
            return true;
        });
        popup.show();
    }

    private void openAdminProtected() {
        SharedPreferences prefs = getSharedPreferences("fasso_admin", MODE_PRIVATE);
        String savedHash = prefs.getString("pin_hash", "");
        EditText pin = new EditText(this);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setHint(savedHash.isEmpty() ? "Créer votre code" : "Code administrateur");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (savedHash.isEmpty()) {
            builder.setTitle("Créer l'accès administrateur")
                    .setMessage("Choisissez un code personnel d'au moins 4 chiffres.")
                    .setView(pin)
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Enregistrer", (d, w) -> {
                        String value = pin.getText().toString().trim();
                        if (value.length() < 4) {
                            Toast.makeText(this, "Le code doit avoir au moins 4 chiffres.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        prefs.edit().putString("pin_hash", sha256(value)).apply();
                        startActivity(new Intent(this, AdminActivity.class));
                    });
        } else {
            builder.setTitle("Administration")
                    .setMessage("Entrez votre code administrateur.")
                    .setView(pin)
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Ouvrir", (d, w) -> {
                        if (sha256(pin.getText().toString().trim()).equals(savedHash)) {
                            startActivity(new Intent(this, AdminActivity.class));
                        } else {
                            Toast.makeText(this, "Code incorrect.", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        builder.show();
    }

    private String sha256(String value) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return value; }
    }

    private void addNavigationItem(LinearLayout navigation, String icon, String label, boolean selected) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView iconView = text(icon, 28, selected ? GREEN : Color.GRAY, false);
        iconView.setGravity(Gravity.CENTER);
        item.addView(iconView);
        TextView labelView = text(label, 14, selected ? GREEN : Color.GRAY, false);
        labelView.setGravity(Gravity.CENTER);
        item.addView(labelView);
        navigation.addView(item, new LinearLayout.LayoutParams(0, 75, 1));
    }
}
