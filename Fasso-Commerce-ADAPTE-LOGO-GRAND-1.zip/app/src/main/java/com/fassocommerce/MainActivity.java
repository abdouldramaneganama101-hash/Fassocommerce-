package com.fassocommerce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int DARK = Color.rgb(25, 35, 45);
    private static final int LIGHT = Color.rgb(247, 249, 248);
    private LinearLayout productContainer;
    private LinearLayout advertisingContainer;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    @Override protected void onResume() {
        super.onResume();
        if (productContainer != null) {
            loadAdvertising();
            loadProducts();
        }
    }

    private void buildScreen() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.WHITE);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(18, 14, 18, 30);
        main.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(10, 8, 6, 8);
        header.setBackgroundColor(GREEN);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, new LinearLayout.LayoutParams(170, 100));

        TextView headerTitle = text("Fasso\nCommerce", 19, Color.WHITE, true);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(headerTitle, new LinearLayout.LayoutParams(0, 100, 1));

        TextView searchIcon = text("⌕", 34, Color.WHITE, false);
        searchIcon.setGravity(Gravity.CENTER);
        header.addView(searchIcon, new LinearLayout.LayoutParams(52, 100));

        TextView menuIcon = text("⋮", 34, Color.WHITE, true);
        menuIcon.setGravity(Gravity.CENTER);
        menuIcon.setContentDescription("Menu");
        menuIcon.setClickable(true);
        menuIcon.setFocusable(true);
        menuIcon.setPadding(6, 0, 6, 0);
        menuIcon.setOnClickListener(v -> showMenu(menuIcon));
        header.addView(menuIcon, new LinearLayout.LayoutParams(50, 70));
        main.addView(header);

        TextView welcome = text("Accueil", 32, DARK, true);
        welcome.setPadding(8, 26, 8, 4);
        main.addView(welcome);

        TextView subtitle = text("Bienvenue chez Fasso Commerce", 19, Color.DKGRAY, false);
        subtitle.setPadding(8, 0, 8, 18);
        main.addView(subtitle);

        TextView contact = text("📞 Commandes et informations : 55883858 / 55284612", 16, GREEN, true);
        contact.setPadding(8, 0, 8, 14);
        main.addView(contact);

        EditText search = new EditText(this);
        search.setHint("Rechercher un produit");
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setPadding(18, 6, 18, 6);
        main.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView adTitle = text("Publicité", 28, DARK, true);
        adTitle.setPadding(8, 22, 8, 10);
        main.addView(adTitle);

        advertisingContainer = new LinearLayout(this);
        advertisingContainer.setOrientation(LinearLayout.VERTICAL);
        advertisingContainer.setGravity(Gravity.CENTER);
        main.addView(advertisingContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        loadAdvertising();

        TextView productsTitle = text("Nos produits", 30, DARK, true);
        productsTitle.setPadding(8, 25, 8, 4);
        main.addView(productsTitle);

        TextView productsSubtitle = text("Découvrez nos produits avec de grandes photos", 17, Color.DKGRAY, false);
        productsSubtitle.setPadding(8, 0, 8, 16);
        main.addView(productsSubtitle);

        productContainer = new LinearLayout(this);
        productContainer.setOrientation(LinearLayout.VERTICAL);
        main.addView(productContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(0, 22, 0, 5);
        addNavigationItem(navigation, "⌂", "Accueil", true);
        addNavigationItem(navigation, "▣", "Nos produits", false);
        addNavigationItem(navigation, "🛒", "Panier", false);
        addNavigationItem(navigation, "●", "Compte", false);
        main.addView(navigation);

        scrollView.addView(main);
        setContentView(scrollView);
        loadProducts();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void loadAdvertising() {
        if (advertisingContainer == null) return;
        advertisingContainer.removeAllViews();
        String uri = ProductStore.getAdvertisingUri(this);
        if (!uri.isEmpty()) {
            ImageView ad = new ImageView(this);
            ad.setAdjustViewBounds(true);
            ad.setScaleType(ImageView.ScaleType.CENTER_CROP);
            try { ad.setImageURI(Uri.parse(uri)); } catch (Exception ignored) {}
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 300);
            p.setMargins(0, 0, 0, 6);
            advertisingContainer.addView(ad, p);
            TextView label = text("Publicité", 14, Color.GRAY, false);
            label.setGravity(Gravity.CENTER);
            advertisingContainer.addView(label);
        } else {
            TextView placeholder = text("PUBLICITÉ\n\nVotre publicité apparaîtra ici\n\nAjoutez une image depuis Administration", 18, Color.WHITE, true);
            placeholder.setGravity(Gravity.CENTER);
            placeholder.setPadding(16, 35, 16, 35);
            placeholder.setBackgroundColor(GREEN);
            advertisingContainer.addView(placeholder, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 260));
        }
    }

    private void loadProducts() {
        if (productContainer == null) return;
        productContainer.removeAllViews();
        JSONArray products = ProductStore.getProducts(this);
        if (products.length() == 0) {
            LinearLayout emptyBox = new LinearLayout(this);
            emptyBox.setOrientation(LinearLayout.VERTICAL); emptyBox.setGravity(Gravity.CENTER);
            emptyBox.setPadding(20, 55, 20, 55); emptyBox.setBackgroundColor(LIGHT);
            TextView icon = text("▣", 62, GREEN, false); icon.setGravity(Gravity.CENTER);
            emptyBox.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 90));
            TextView title = text("Aucun produit pour le moment", 23, DARK, true); title.setGravity(Gravity.CENTER);
            emptyBox.addView(title);
            TextView info = text("Les produits seront ajoutés avec leurs grandes photos, prix et descriptions.", 16, Color.DKGRAY, false);
            info.setGravity(Gravity.CENTER); info.setPadding(10, 10, 10, 0); emptyBox.addView(info);
            productContainer.addView(emptyBox);
            return;
        }

        for (int i = 0; i < products.length(); i++) {
            try {
                JSONObject p = products.getJSONObject(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12, 12, 12, 18); card.setBackgroundColor(LIGHT);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cp.setMargins(0, 0, 0, 18);

                JSONArray photos=p.optJSONArray("imageUris");
                if(photos==null){photos=new JSONArray();String legacy=p.optString("imageUri","");if(!legacy.isEmpty())photos.put(legacy);}
                if(photos.length()>0){
                    LinearLayout gallery=new LinearLayout(this); gallery.setOrientation(LinearLayout.VERTICAL);
                    for(int j=0;j<photos.length();j++){String imageUri=photos.optString(j,"");if(!imageUri.isEmpty()){ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.CENTER_CROP);try{image.setImageURI(Uri.parse(imageUri));}catch(Exception ignored){}LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,360);ip.setMargins(0,0,0,14);gallery.addView(image,ip);}}
                    card.addView(gallery,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
                }

                TextView name = text(p.optString("name", "Produit"), 24, DARK, true); name.setPadding(8, 12, 8, 3); card.addView(name);
                TextView price = text("Prix : " + p.optString("price", "À préciser"), 20, GREEN, true); price.setPadding(8, 0, 8, 4); card.addView(price);
                TextView stock = text("Stock : " + p.optString("stock", "0"), 16, Color.DKGRAY, false); stock.setPadding(8, 0, 8, 3); card.addView(stock);
                String descriptionText = p.optString("description", "");
                if (!descriptionText.isEmpty()) {
                    TextView description = text(descriptionText, 16, Color.DKGRAY, false); description.setPadding(8, 0, 8, 4); card.addView(description);
                }
                Button orderButton = new Button(this);
                orderButton.setText("🛒 Passer commande");
                orderButton.setTextSize(17);
                orderButton.setTextColor(Color.WHITE);
                orderButton.setBackgroundColor(GREEN);
                orderButton.setOnClickListener(v -> showOrderDialog(p));
                card.addView(orderButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                productContainer.addView(card, cp);
            } catch (Exception ignored) {}
        }
    }

    private void showOrderDialog(JSONObject product) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(8, 4, 8, 4);
        EditText customer = new EditText(this); customer.setHint("Nom du client");
        EditText phone = new EditText(this); phone.setHint("Téléphone"); phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText address = new EditText(this); address.setHint("Lieu / adresse de livraison");
        EditText quantity = new EditText(this); quantity.setHint("Quantité"); quantity.setInputType(InputType.TYPE_CLASS_NUMBER); quantity.setText("1");
        form.addView(customer); form.addView(phone); form.addView(address); form.addView(quantity);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Passer commande").setMessage(product.optString("name", "Produit") + " — " + product.optString("price", "Prix à préciser"))
                .setView(form).setNegativeButton("Annuler", null).setPositiveButton("Envoyer la commande", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String c=customer.getText().toString().trim(), ph=phone.getText().toString().trim(), a=address.getText().toString().trim(), q=quantity.getText().toString().trim();
            if(c.isEmpty()){customer.setError("Nom obligatoire");return;}
            if(ph.isEmpty()){phone.setError("Téléphone obligatoire");return;}
            if(a.isEmpty()){address.setError("Lieu de livraison obligatoire");return;}
            if(q.isEmpty() || q.equals("0")){quantity.setError("Quantité obligatoire");return;}
            try { OrderStore.addOrder(this, product.optString("name","Produit"), product.optString("price",""), c, ph, a, q); dialog.dismiss(); Toast.makeText(this,"Commande envoyée. Elle est visible dans Administration > Commandes reçues.",Toast.LENGTH_LONG).show(); } catch(Exception e){Toast.makeText(this,"Impossible d'envoyer la commande.",Toast.LENGTH_LONG).show();}
        }));
        dialog.show();
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("🔐 Administration"); popup.getMenu().add("Fermer");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle().toString().contains("Administration")) { openAdminProtected(); }
            return true;
        });
        popup.show();
    }

    private void openAdminProtected() {
        SharedPreferences prefs = getSharedPreferences("fasso_admin", MODE_PRIVATE);
        String savedHash = prefs.getString("pin_hash", "");
        EditText pin = new EditText(this);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setHint(savedHash.isEmpty() ? "Créer votre code" : "Code administrateur");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(savedHash.isEmpty() ? "Créer le code administrateur" : "Administration")
                .setMessage(savedHash.isEmpty() ? "Choisissez un code PIN pour protéger l'administration." : "Entrez votre code PIN.")
                .setView(pin).setNegativeButton("Annuler", null).setPositiveButton("Continuer", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String entered = pin.getText().toString().trim();
            if (entered.length() < 4) { pin.setError("Minimum 4 chiffres"); return; }
            if (savedHash.isEmpty()) {
                prefs.edit().putString("pin_hash", entered).apply();
                dialog.dismiss(); startActivity(new Intent(this, AdminActivity.class));
            } else if (entered.equals(savedHash)) {
                dialog.dismiss(); startActivity(new Intent(this, AdminActivity.class));
            } else { pin.setError("Code incorrect"); }
        }));
        dialog.show();
    }

    private void addNavigationItem(LinearLayout parent, String icon, String label, boolean active) {
        LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
        TextView i = text(icon, 25, active ? GREEN : Color.GRAY, true); i.setGravity(Gravity.CENTER);
        TextView t = text(label, 12, active ? GREEN : Color.GRAY, active); t.setGravity(Gravity.CENTER);
        item.addView(i); item.addView(t);
        parent.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    }
}
