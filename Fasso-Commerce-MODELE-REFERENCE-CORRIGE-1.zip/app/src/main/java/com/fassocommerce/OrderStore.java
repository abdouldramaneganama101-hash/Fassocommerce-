package com.fassocommerce;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public final class OrderStore {
    private static final String PREFS = "fasso_orders";
    private static final String KEY = "orders";
    private OrderStore() {}

    public static JSONArray getOrders(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context context, JSONArray orders) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, orders.toString()).apply();
    }

    public static void addOrder(Context context, String productName, String price, String customer,
                                String phone, String address, String quantity) throws Exception {
        JSONArray orders = getOrders(context);
        JSONObject o = new JSONObject();
        o.put("id", System.currentTimeMillis());
        o.put("product", productName);
        o.put("price", price);
        o.put("customer", customer);
        o.put("phone", phone);
        o.put("address", address);
        o.put("quantity", quantity);
        o.put("status", "Nouvelle");
        o.put("date", new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()));
        orders.put(o);
        save(context, orders);
    }

    public static void updateStatus(Context context, int index, String status) throws Exception {
        JSONArray orders = getOrders(context);
        if (index < 0 || index >= orders.length()) return;
        orders.getJSONObject(index).put("status", status);
        save(context, orders);
    }

    public static void deleteOrder(Context context, int index) {
        JSONArray orders = getOrders(context);
        if (index < 0 || index >= orders.length()) return;
        orders.remove(index);
        save(context, orders);
    }
}
