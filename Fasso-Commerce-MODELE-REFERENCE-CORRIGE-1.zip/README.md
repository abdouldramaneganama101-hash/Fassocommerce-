# Fasso Commerce 1.2

Application Android de commerce avec :
- accueil Fasso Commerce et logo ;
- espace Publicité avec image administrable ;
- produits avec grandes photos ;
- bouton Passer commande pour chaque produit ;
- formulaire client : nom, téléphone, lieu/adresse et quantité ;
- administration privée protégée par PIN ;
- commandes reçues visibles dans Administration > Commandes reçues ;
- changement du statut d'une commande et suppression ;
- compte vendeur avec nom, téléphone, adresse de réception et mode de paiement ;
- ajout, modification et suppression des produits ;
- gestion de la publicité.

Les données de cette version de test sont stockées localement sur le téléphone. Une version de production devra utiliser un serveur sécurisé et une base de données en ligne pour synchroniser les commandes et les comptes.

## Version 1.2
- Un produit peut maintenant contenir plusieurs photos.
- Dans Administration, le sélecteur permet de sélectionner plusieurs images en une seule fois.
- Les photos sont affichées dans une galerie horizontale sur l'accueil et dans l'administration.
