package com.fassocommerce;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int DARK = Color.rgb(25, 35, 45);
    private static final int LIGHT = Color.rgb(247, 249, 248);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.WHITE);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(22, 18, 22, 35);
        main.setBackgroundColor(Color.WHITE);

        // En-tête Fasso Commerce
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 10, 12, 10);
        header.setBackgroundColor(GREEN);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, new LinearLayout.LayoutParams(95, 70));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("Fasso\nCommerce");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(19);
        headerTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(headerTitle, new LinearLayout.LayoutParams(0, 70, 1));

        TextView searchIcon = new TextView(this);
        searchIcon.setText("⌕");
        searchIcon.setTextColor(Color.WHITE);
        searchIcon.setTextSize(34);
        searchIcon.setGravity(Gravity.CENTER);
        header.addView(searchIcon, new LinearLayout.LayoutParams(55, 70));

        TextView menuIcon = new TextView(this);
        menuIcon.setText("⋮");
        menuIcon.setTextColor(Color.WHITE);
        menuIcon.setTextSize(32);
        menuIcon.setGravity(Gravity.CENTER);
        header.addView(menuIcon, new LinearLayout.LayoutParams(35, 70));

        main.addView(header);

        // Titre de l'accueil
        TextView welcome = new TextView(this);
        welcome.setText("Accueil");
        welcome.setTextSize(34);
        welcome.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        welcome.setTextColor(DARK);
        welcome.setPadding(8, 28, 8, 5);
        main.addView(welcome);

        TextView subtitle = new TextView(this);
        subtitle.setText("Bienvenue chez Fasso Commerce");
        subtitle.setTextSize(20);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(8, 0, 8, 20);
        main.addView(subtitle);

        // Recherche
        EditText search = new EditText(this);
        search.setHint("Rechercher un produit");
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setPadding(18, 8, 18, 8);
        main.addView(search, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Publicité / photos d'accueil
        TextView advertising = new TextView(this);
        advertising.setText("PUBLICITÉ\n\nDécouvrez ici vos prochaines publicités et photos de produits");
        advertising.setTextSize(19);
        advertising.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        advertising.setTextColor(Color.WHITE);
        advertising.setGravity(Gravity.CENTER);
        advertising.setPadding(15, 38, 15, 38);
        advertising.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams adParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        adParams.setMargins(0, 22, 0, 25);
        main.addView(advertising, adParams);

        // Section Nos produits : vide au départ
        TextView productsTitle = new TextView(this);
        productsTitle.setText("Nos produits");
        productsTitle.setTextSize(30);
        productsTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        productsTitle.setTextColor(DARK);
        productsTitle.setPadding(8, 5, 8, 4);
        main.addView(productsTitle);

        TextView productsSubtitle = new TextView(this);
        productsSubtitle.setText("Découvrez tous nos produits");
        productsSubtitle.setTextSize(18);
        productsSubtitle.setTextColor(Color.DKGRAY);
        productsSubtitle.setPadding(8, 0, 8, 18);
        main.addView(productsSubtitle);

        LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER);
        emptyBox.setPadding(20, 55, 20, 55);
        emptyBox.setBackgroundColor(LIGHT);

        TextView boxIcon = new TextView(this);
        boxIcon.setText("▣");
        boxIcon.setTextSize(62);
        boxIcon.setTextColor(GREEN);
        boxIcon.setGravity(Gravity.CENTER);
        emptyBox.addView(boxIcon, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 90));

        TextView emptyTitle = new TextView(this);
        emptyTitle.setText("Aucun produit pour le moment");
        emptyTitle.setTextSize(23);
        emptyTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        emptyTitle.setTextColor(DARK);
        emptyTitle.setGravity(Gravity.CENTER);
        emptyTitle.setPadding(0, 10, 0, 10);
        emptyBox.addView(emptyTitle);

        TextView emptyText = new TextView(this);
        emptyText.setText("Les produits seront ajoutés avec leurs photos, prix et descriptions.");
        emptyText.setTextSize(17);
        emptyText.setTextColor(Color.DKGRAY);
        emptyText.setGravity(Gravity.CENTER);
        emptyBox.addView(emptyText);

        LinearLayout.LayoutParams emptyParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        emptyParams.setMargins(0, 5, 0, 20);
        main.addView(emptyBox, emptyParams);

        // Navigation client uniquement
        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(0, 10, 0, 5);

        addNavigationItem(navigation, "⌂", "Accueil", true);
        addNavigationItem(navigation, "▣", "Nos produits", false);
        addNavigationItem(navigation, "🛒", "Panier", false);
        addNavigationItem(navigation, "●", "Compte", false);
        main.addView(navigation);

        scrollView.addView(main);
        setContentView(scrollView);
    }

    private void addNavigationItem(LinearLayout navigation, String icon, String label, boolean selected) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(28);
        iconView.setGravity(Gravity.CENTER);
        iconView.setTextColor(selected ? GREEN : Color.GRAY);
        item.addView(iconView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(14);
        labelView.setGravity(Gravity.CENTER);
        labelView.setTextColor(selected ? GREEN : Color.GRAY);
        item.addView(labelView);

        navigation.addView(item, new LinearLayout.LayoutParams(0, 75, 1));
    }
}
