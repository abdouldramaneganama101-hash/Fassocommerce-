plugins {
    id("com.android.application")
}

android {
    namespace = "com.fassocommerce"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.fassocommerce"
        minSdk = 23
        targetSdk = 36
        versionCode = 7
        versionName = "1.6"
    }
}
