package com.fassocommerce;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int ORANGE = Color.rgb(255,102,0);
    private static final int DARK = Color.rgb(24,37,58);
    private static final int GRAY = Color.rgb(92,105,124);
    private static final int LIGHT = Color.rgb(248,249,251);

    private LinearLayout catalog;
    private TextView cartBadge;
    private final List<CartItem> cartItems = new ArrayList<>();
    private String currentFilter = "";

    private static class CartItem {
        String name, price;
        int quantity;
        CartItem(String n, String p) { name=n; price=p; quantity=1; }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildScreen();
        if (!getPreferences(MODE_PRIVATE).getBoolean("first_run_guide_seen", false)) {
            showGuideStep(0);
        }
    }
    @Override protected void onResume() { super.onResume(); if (catalog != null) loadCatalog(); }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView txt(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private Button orangeButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(rounded(ORANGE, 18)); b.setPadding(dp(10),0,dp(10),0); return b;
    }
    private ImageView image(int res, int w, int h) {
        ImageView v = new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(rounded(Color.WHITE, 16)); v.setAdjustViewBounds(true);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),dp(h))); return v;
    }

    private void buildScreen() {
        LinearLayout screen = new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setClipChildren(false);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo_orange);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(0,dp(82),1f);
        lpLogo.setMargins(0,0,dp(4),0);
        header.addView(logo,lpLogo);

        Button bell = orangeButton("🔔");
        bell.setTextSize(17);
        bell.setPadding(0,0,0,0);
        header.addView(bell,new LinearLayout.LayoutParams(dp(44),dp(44)));

        Button cart = orangeButton("🛒");
        cart.setTextSize(17);
        cart.setPadding(0,0,0,0);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(44),dp(44));
        cp.setMargins(dp(5),0,0,0);
        header.addView(cart,cp);
        cart.setOnClickListener(v->showCartDialog());
        root.addView(header);

        cartBadge = txt("Panier : 0 article",14,GRAY,false);
        cartBadge.setGravity(Gravity.RIGHT); root.addView(cartBadge);
        bell.setOnClickListener(v->showInfo("Notifications","Les notifications de commande apparaîtront ici dans la version en ligne."));

        EditText search = new EditText(this); search.setHint("🔎  Rechercher un produit..."); search.setTextSize(17);
        search.setSingleLine(true); search.setPadding(dp(16),0,dp(12),0); search.setBackground(rounded(Color.rgb(245,246,248),28));
        LinearLayout.LayoutParams sr=new LinearLayout.LayoutParams(-1,dp(58));sr.setMargins(0,dp(5),0,dp(10));root.addView(search,sr);
        search.setOnEditorActionListener((v,a,e)->{ currentFilter=search.getText().toString().trim(); loadCatalog(); return true; });

        HorizontalScrollView tabScroll=new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(0,dp(2),0,dp(4));
        String[] tabNames={"⌂  Accueil","▦  Produits","▢  Catégories","▥  Fabricants","◎  Mondial"};
        for(int i=0;i<tabNames.length;i++){
            TextView t=txt(tabNames[i],14,i==0?Color.WHITE:DARK,true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(12),0,dp(12),0);
            t.setBackground(rounded(i==0?ORANGE:Color.WHITE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(52));p.setMargins(dp(2),0,dp(5),0);tabs.addView(t,p);
            final int idx=i; t.setOnClickListener(v->{
                if(idx==0){currentFilter="";loadCatalog();}
                else if(idx==1){currentFilter="";loadCatalog();}
                else if(idx==2){showCategoriesDialog();}
                else if(idx==3){showInfo("Fabricants","Fasso Commerce présente des équipements de différentes marques et fabricants.");}
                else {showInfo("Mondial","Découvrez des produits et équipements disponibles sur demande.");}
            });
        }
        tabScroll.addView(tabs);root.addView(tabScroll);

        ScrollView contentScroll = new ScrollView(this);
        contentScroll.setBackgroundColor(Color.WHITE);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0,dp(4),0,dp(10));

        HorizontalScrollView catScroll=new HorizontalScrollView(this);catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout cats=new LinearLayout(this);cats.setPadding(0,dp(12),0,dp(8));
        addCategory(cats,R.drawable.tondeuse,"Tondeuses","Tondeuse");
        addCategory(cats,R.drawable.fer_repasser,"Fer à repasser","Fer");
        addCategory(cats,R.drawable.aspirateur_voiture,"Aspirateurs\nvoiture","Aspirateur");
        addCategory(cats,R.drawable.compresseur,"Compresseurs","Compresseur");
        addCategory(cats,R.drawable.outillage,"Outillage","Outillage");
        addCategoryPlaceholder(cats,"•••","Autres");
        catScroll.addView(cats);content.addView(catScroll);

        LinearLayout services=new LinearLayout(this); services.setOrientation(LinearLayout.HORIZONTAL); services.setPadding(dp(10),dp(8),dp(10),dp(8));
        services.setBackground(rounded(Color.rgb(255,244,237),18));
        LinearLayout delivery=serviceBox("🚚","Livraison","Rapide et fiable",false);
        LinearLayout quote=serviceBox("▤","Demander un devis","Sans engagement",true);
        services.addView(delivery,new LinearLayout.LayoutParams(0,dp(90),1));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(90),1);qp.setMargins(dp(8),0,0,0);services.addView(quote,qp);
        delivery.setOnClickListener(v->showInfo("Livraison","Contactez Fasso Commerce pour connaître les frais et le délai selon votre lieu."));
        quote.setOnClickListener(v->showQuoteDialog()); content.addView(services);

        LinearLayout title=new LinearLayout(this);title.setGravity(Gravity.CENTER_VERTICAL);title.setPadding(dp(5),dp(12),dp(5),dp(5));
        TextView top=txt("Top ventes",25,DARK,true);title.addView(top,new LinearLayout.LayoutParams(0,dp(55),1));TextView all=txt("Voir tout  ›",16,ORANGE,true);title.addView(all);content.addView(title);
        all.setOnClickListener(v->{currentFilter="";loadCatalog();});

        catalog=new LinearLayout(this);catalog.setOrientation(LinearLayout.VERTICAL);content.addView(catalog);
        contentScroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
        addBottomNav(root);
        screen.addView(root,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(screen);loadCatalog();
    }

    private void addCategory(LinearLayout parent,int res,String name,String filter){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(7),dp(7),dp(7),dp(5));box.setBackground(rounded(LIGHT,16));
        ImageView im=image(res,105,92);box.addView(im);TextView t=txt(name,14,DARK,true);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(5),0,0);box.addView(t);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(138),dp(178));p.setMargins(0,0,dp(8),0);parent.addView(box,p);box.setOnClickListener(v->{currentFilter=filter;loadCatalog();});
    }
    private void addCategoryPlaceholder(LinearLayout parent,String icon,String name){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setBackground(rounded(LIGHT,16));TextView i=txt(icon,28,GRAY,true);i.setGravity(Gravity.CENTER);box.addView(i,new LinearLayout.LayoutParams(-1,dp(110)));TextView t=txt(name,14,DARK,true);t.setGravity(Gravity.CENTER);box.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(118),dp(178));p.setMargins(0,0,dp(8),0);parent.addView(box,p);box.setOnClickListener(v->showCategoriesDialog());
    }
    private LinearLayout serviceBox(String icon,String title,String sub,boolean orange){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.HORIZONTAL);b.setGravity(Gravity.CENTER_VERTICAL);b.setPadding(dp(8),dp(5),dp(8),dp(5));b.setBackground(rounded(orange?ORANGE:Color.rgb(255,239,229),16));TextView ic=txt(icon,32,orange?Color.WHITE:ORANGE,true);ic.setGravity(Gravity.CENTER);b.addView(ic,new LinearLayout.LayoutParams(dp(52),-1));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView a=txt(title,17,orange?Color.WHITE:DARK,true);TextView c=txt(sub,12,orange?Color.WHITE:GRAY,false);tx.addView(a);tx.addView(c);b.addView(tx);return b;}

    private void loadCatalog(){
        if(catalog==null)return; catalog.removeAllViews();
        addProductCard(R.drawable.tondeuse,"Tondeuse thermique","125 000 FCFA",12,"Tondeuse");
        addProductCard(R.drawable.fer_repasser,"Fer à repasser","15 500 FCFA",8,"Fer");
        addProductCard(R.drawable.aspirateur_voiture,"Aspirateur voiture","12 000 FCFA",6,"Aspirateur");
        addProductCard(R.drawable.compresseur,"Petit compresseur","75 000 FCFA",5,"Compresseur");
        addProductCard(R.drawable.outillage,"Outillage","Prix sur demande",4,"Outillage");
        JSONArray ps=ProductStore.getProducts(this);
        for(int i=0;i<ps.length();i++){try{JSONObject p=ps.getJSONObject(i);addStoredProductCard(p);}catch(Exception ignored){}}
        updateCartBadge();
    }

    private boolean matches(String name,String category){return currentFilter.isEmpty() || name.toLowerCase().contains(currentFilter.toLowerCase()) || category.toLowerCase().contains(currentFilter.toLowerCase());}
    private void addProductCard(int res,String name,String price,int reviews,String category){
        if(!matches(name,category))return;
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(rounded(Color.WHITE,18));
        ImageView im=image(res,150,120);card.addView(im);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(4),0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView n=txt(name,18,DARK,true);info.addView(n);TextView stars=txt("★★★★★  ("+reviews+")",14,ORANGE,true);stars.setPadding(0,dp(6),0,dp(4));info.addView(stars);TextView pr=txt(price,18,ORANGE,true);info.addView(pr);
        Button b=orangeButton("🛒");b.setTextSize(20);card.addView(b,new LinearLayout.LayoutParams(dp(55),dp(55)));b.setOnClickListener(v->addToCart(name,price));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(142));cp.setMargins(0,0,0,dp(10));catalog.addView(card,cp);
    }
    private void addStoredProductCard(JSONObject p){
        String name=p.optString("name","Produit"), price=p.optString("price","Prix à préciser"), uri=p.optString("imageUri","");String category=p.optString("category","");if(!matches(name,category))return;
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(rounded(Color.WHITE,18));ImageView im=new ImageView(this);im.setBackground(rounded(Color.WHITE,16));im.setScaleType(ImageView.ScaleType.CENTER_CROP);if(!uri.isEmpty())try{im.setImageURI(Uri.parse(uri));}catch(Exception ignored){}card.addView(im,new LinearLayout.LayoutParams(dp(150),dp(120)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(4),0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));info.addView(txt(name,18,DARK,true));info.addView(txt(category.isEmpty()?"Nouveau produit":category,14,GRAY,false));info.addView(txt(price+" FCFA",18,ORANGE,true));Button b=orangeButton("🛒");card.addView(b,new LinearLayout.LayoutParams(dp(55),dp(55)));b.setOnClickListener(v->addToCart(name,price));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(142));cp.setMargins(0,0,0,dp(10));catalog.addView(card,cp);
    }

    private void addToCart(String name,String price){for(CartItem x:cartItems)if(x.name.equals(name)){x.quantity++;updateCartBadge();Toast.makeText(this,"Quantité augmentée : "+name,Toast.LENGTH_SHORT).show();return;}cartItems.add(new CartItem(name,price));updateCartBadge();Toast.makeText(this,name+" ajouté au panier",Toast.LENGTH_SHORT).show();}
    private void updateCartBadge(){if(cartBadge==null)return;int total=0;for(CartItem x:cartItems)total+=x.quantity;cartBadge.setText("Panier : "+total+" article"+(total>1?"s":""));}

    private void showCartDialog(){
        if(cartItems.isEmpty()){showInfo("Panier","Votre panier est vide. Appuyez sur 🛒 sur un produit pour l'ajouter.");return;}

        LinearLayout outer=new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(10),0,dp(10),dp(8));

        TextView summary=txt("",17,DARK,true);
        summary.setPadding(dp(4),dp(8),dp(4),dp(8));
        outer.addView(summary);

        ScrollView listScroll=new ScrollView(this);
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        listScroll.addView(list);
        outer.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1));

        for(CartItem x:cartItems){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6),dp(8),dp(6),dp(8));
            row.setBackground(rounded(Color.rgb(248,249,251),14));
            TextView t=txt(x.name+"\n"+x.price+" × "+x.quantity,15,DARK,true);
            row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Button minus=orangeButton("−");
            minus.setTextSize(18);
            Button plus=orangeButton("+");
            plus.setTextSize(18);
            row.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(42),dp(42));
            pp.setMargins(dp(5),0,0,0);
            row.addView(plus,pp);
            minus.setOnClickListener(v->{if(x.quantity>1)x.quantity--;else cartItems.remove(x);updateCartBadge();showCartDialog();});
            plus.setOnClickListener(v->{x.quantity++;updateCartBadge();showCartDialog();});
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);
            rp.setMargins(0,0,0,dp(7));
            list.addView(row,rp);
        }

        int total=0;
        for(CartItem x:cartItems){
            try{
                String clean=x.price.replace("FCFA"," ").replace(" ","").replace(".","").replace(",","");
                total+=Integer.parseInt(clean)*x.quantity;
            }catch(Exception ignored){}
        }
        summary.setText("Total : "+(total>0?total+" FCFA":"Prix à confirmer")+"\n"+cartItems.size()+" produit(s) dans le panier");

        Button order=orangeButton("✓  VALIDER LA COMMANDE");
        order.setTextSize(16);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(56));
        op.setMargins(0,dp(8),0,0);
        outer.addView(order,op);
        order.setOnClickListener(v->showOrderForm());

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("🛒 Mon panier")
                .setView(outer)
                .setNegativeButton("Fermer",null)
                .create();
        dialog.show();
    }
    private void showOrderForm(){
        LinearLayout f=new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(10),0,dp(10),0);
        EditText name=new EditText(this); name.setHint("Votre nom");
        EditText phone=new EditText(this); phone.setHint("Téléphone"); phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText address=new EditText(this); address.setHint("Lieu / adresse de livraison");
        f.addView(name); f.addView(phone); f.addView(address);

        TextView rule=txt("🚚 Livraison uniquement le mercredi et le dimanche",15,ORANGE,true);
        rule.setPadding(dp(4),dp(12),dp(4),dp(8));
        f.addView(rule);

        Spinner daySpinner=new Spinner(this);
        ArrayAdapter<String> days=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Mercredi","Dimanche"});
        daySpinner.setAdapter(days);
        f.addView(daySpinner);

        Spinner timeSpinner=new Spinner(this);
        ArrayAdapter<String> times=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{
                "08h00 - 10h00","10h00 - 12h00","14h00 - 16h00","16h00 - 18h00"});
        timeSpinner.setAdapter(times);
        f.addView(timeSpinner);

        new AlertDialog.Builder(this)
                .setTitle("Confirmer la commande")
                .setMessage("Choisissez le jour et le créneau de livraison, puis le mode de paiement.")
                .setView(f)
                .setNegativeButton("Annuler",null)
                .setPositiveButton("Continuer",(d,w)->{
                    String customer=name.getText().toString().trim(), ph=phone.getText().toString().trim(), ad=address.getText().toString().trim();
                    if(customer.isEmpty()||ph.isEmpty()||ad.isEmpty()){
                        Toast.makeText(this,"Nom, téléphone et adresse sont obligatoires.",Toast.LENGTH_LONG).show();
                        return;
                    }
                    String deliveryDay=daySpinner.getSelectedItem().toString();
                    String deliveryTime=timeSpinner.getSelectedItem().toString();
                    showPaymentDialog(customer,ph,ad,deliveryDay,deliveryTime);
                }).show();
    }

    private int cartTotal(){
        int total=0;
        for(CartItem x:cartItems){
            try{
                String clean=x.price.replace("FCFA"," ").replace(" ","").replace(".","").replace(",","");
                total += Integer.parseInt(clean)*x.quantity;
            }catch(Exception ignored){}
        }
        return total;
    }

    private void showPaymentDialog(String customer,String phone,String address,String deliveryDay,String deliveryTime){
        int total=cartTotal();
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(6),dp(12),dp(6));
        TextView amount=txt("Total à payer : "+(total>0?total+" FCFA":"Prix à confirmer"),18,DARK,true);
        box.addView(amount);

        TextView orange=txt("🟠  Orange Money",18,DARK,true);
        orange.setPadding(dp(12),dp(14),dp(12),dp(14));
        orange.setBackground(rounded(Color.rgb(255,244,237),16));
        box.addView(orange);

        TextView delivery=txt("🚚 Livraison : "+deliveryDay+" — "+deliveryTime,16,DARK,true);
        delivery.setPadding(dp(12),dp(8),dp(12),dp(8));
        box.addView(delivery);

        TextView info=txt("Paiement Orange Money\nCompte marchand : 55284612\nMontant automatique : "+(total>0?total+" FCFA":"à confirmer")+"\n\nFasso Commerce ne demande jamais le PIN Orange Money. Le statut « Payé » doit être confirmé par un paiement réel.",14,GRAY,false);
        info.setPadding(dp(12),dp(10),dp(12),0);
        box.addView(info);

        Button copy=orangeButton("📋 Copier le numéro marchand");
        copy.setTextSize(15);
        box.addView(copy,new LinearLayout.LayoutParams(-1,dp(50)));
        copy.setOnClickListener(v->{
            ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("Orange Money", "55284612"));
            Toast.makeText(this,"Numéro marchand copié.",Toast.LENGTH_SHORT).show();
        });
        Button pay=orangeButton("🟠  Instructions de paiement");
        pay.setTextSize(16);
        LinearLayout.LayoutParams payLp=new LinearLayout.LayoutParams(-1,dp(54)); payLp.setMargins(0,dp(6),0,0); box.addView(pay,payLp);
        pay.setOnClickListener(v->showInfo("Paiement Orange Money", "Montant à payer : "+(total>0?total+" FCFA":"à confirmer")+"\nNuméro marchand : 55284612\n\nOuvrez Orange Money, choisissez le paiement marchand, saisissez le numéro marchand et le montant affiché. Ne communiquez jamais votre PIN à Fasso Commerce.\n\nLe statut de la commande reste « Non payé » jusqu'à confirmation du paiement."));

        new AlertDialog.Builder(this)
                .setTitle("Paiement")
                .setView(box)
                .setNegativeButton("Annuler",null)
                .setPositiveButton("Commander — non payé",(d,w)->{
                    for(CartItem x:cartItems){
                        try{
                            OrderStore.addOrder(this,x.name,x.price,customer,phone,address,String.valueOf(x.quantity),"Orange Money","Non payé",deliveryDay,deliveryTime,String.valueOf(total));
                        }catch(Exception ignored){}
                    }
                    cartItems.clear();
                    updateCartBadge();
                    Toast.makeText(this,"Commande enregistrée. Paiement : Non payé.",Toast.LENGTH_LONG).show();
                }).show();
    }

    private void addBottomNav(LinearLayout root){
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(0,dp(4),0,dp(4));
        nav.setBackgroundColor(Color.WHITE);
        nav.setElevation(dp(8));String[] items={"⌂\nAccueil","▦\nCatégories","💬\nMessagerie","🛒\nPanier","♙\nCompte"};
        for(int i=0;i<items.length;i++){TextView t=txt(items[i],13,i==0?ORANGE:DARK,i==0);t.setGravity(Gravity.CENTER);nav.addView(t,new LinearLayout.LayoutParams(0,dp(70),1));final int idx=i;t.setOnClickListener(v->{if(idx==0){currentFilter="";loadCatalog();}else if(idx==1)showCategoriesDialog();else if(idx==2)showMessaging();else if(idx==3)showCartDialog();else showAccountMenu();});}root.addView(nav);
    }
    private void showCategoriesDialog(){String[] c={"Tondeuses","Fer à repasser","Aspirateurs voiture","Compresseurs","Outillage","Tous les produits"};final String[] f={"Tondeuse","Fer","Aspirateur","Compresseur","Outillage",""};new AlertDialog.Builder(this).setTitle("Catégories").setItems(c,(d,w)->{currentFilter=f[w];loadCatalog();}).show();}
    private void showMessaging(){
        JSONArray ms=MessageStore.getMessages(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(4),dp(10),dp(4));
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<ms.length();i++){
            JSONObject m=ms.optJSONObject(i); if(m==null) continue;
            list.addView(txt(m.optString("sender","Client")+" — "+m.optString("date","")+"\n"+m.optString("text",""),15,DARK,false));
        }
        if(ms.length()==0) list.addView(txt("Aucun message. Vous pouvez écrire directement à Fasso Commerce.",15,GRAY,false));
        scroll.addView(list); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView contact=txt("Service client : 55 88 38 58",15,ORANGE,true); contact.setPadding(0,dp(6),0,dp(6)); box.addView(contact);
        LinearLayout contactRow=new LinearLayout(this); contactRow.setOrientation(LinearLayout.HORIZONTAL);
        Button call=orangeButton("📞 Appeler"); Button sms=orangeButton("✉ SMS");
        contactRow.addView(call,new LinearLayout.LayoutParams(0,dp(48),1)); LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(0,dp(48),1); slp.setMargins(dp(6),0,0,0); contactRow.addView(sms,slp); box.addView(contactRow);
        call.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:55883858")));}catch(Exception ignored){}});
        sms.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:55883858")));}catch(Exception ignored){}});
        EditText input=new EditText(this); input.setHint("Écrire un message..."); input.setMinLines(2); box.addView(input);
        Button send=orangeButton("Envoyer le message"); box.addView(send,new LinearLayout.LayoutParams(-1,dp(52)));
        send.setOnClickListener(v->{String t=input.getText().toString().trim(); if(t.isEmpty()){Toast.makeText(this,"Écrivez un message.",Toast.LENGTH_SHORT).show();return;} try{MessageStore.add(this,"Client",t);input.setText("");Toast.makeText(this,"Message envoyé dans la boîte de réception.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Impossible d'envoyer le message.",Toast.LENGTH_LONG).show();}});
        MessageStore.markAllRead(this);
        new AlertDialog.Builder(this).setTitle("💬 Messagerie Fasso Commerce").setView(box).setNegativeButton("Fermer",null).show();
    }
    private void showAccountMenu(){new AlertDialog.Builder(this).setTitle("Compte").setItems(new String[]{"Mes commandes","Administration (privé)","Informations boutique","Revoir le guide d’utilisation"},(d,w)->{if(w==0)showOrders();else if(w==1)askAdminPin();else if(w==2)showInfo("Fasso Commerce","Boutique de matériel et équipements.\nTéléphones : 55883858 / 55284612");else showGuideStep(0);}).show();}
    private void showOrders(){
        JSONArray os=OrderStore.getOrders(this);
        if(os.length()==0){showInfo("Mes commandes","Aucune commande enregistrée sur cet appareil.");return;}
        String[] items=new String[os.length()];
        for(int i=0;i<os.length();i++){
            JSONObject o=os.optJSONObject(i);
            if(o==null){items[i]="Commande indisponible";continue;}
            items[i]="Commande #"+o.optLong("id")+" — "+o.optString("status","Nouvelle")+"\n"+o.optString("product")+" × "+o.optString("quantity");
        }
        new AlertDialog.Builder(this)
                .setTitle("Mes commandes — Suivi")
                .setItems(items,(d,w)->showOrderTracking(os.optJSONObject(w)))
                .setNegativeButton("Fermer",null).show();
    }

    private void showOrderTracking(JSONObject o){
        if(o==null)return;
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(4),dp(12),dp(4));

        TextView head=txt("Commande #"+o.optLong("id")+"\n"+o.optString("product")+" × "+o.optString("quantity")+"\nPrix : "+o.optString("price"),16,DARK,true);
        head.setPadding(0,0,0,dp(10));
        box.addView(head);

        String current=o.optString("status","Nouvelle");
        String[] steps={"Nouvelle","Confirmée","En préparation","Prête","Livrée"};
        int currentIndex=-1;
        for(int i=0;i<steps.length;i++)if(steps[i].equals(current))currentIndex=i;
        for(int i=0;i<steps.length;i++){
            TextView step=txt((i<=currentIndex?"✓ ":"○ ")+steps[i],16,i<=currentIndex?ORANGE:GRAY,i==currentIndex);
            step.setPadding(dp(10),dp(10),dp(10),dp(10));
            box.addView(step);
        }
        if("Annulée".equals(current)){
            TextView cancelled=txt("✕ Commande annulée",16,Color.rgb(190,40,40),true);
            cancelled.setPadding(dp(10),dp(10),dp(10),dp(10));box.addView(cancelled);
        }
        box.addView(txt("\nDernière mise à jour : "+o.optString("statusDate",o.optString("date","")),14,GRAY,false));
        box.addView(txt("Total : "+o.optString("total",o.optString("price","Non précisé"))+" FCFA\nPaiement : "+o.optString("paymentMethod","Non précisé")+"\nStatut paiement : "+o.optString("paymentStatus","Non précisé"),14,GRAY,false));
        box.addView(txt("\nLivraison : "+o.optString("address","Non précisée")+"\nJour : "+o.optString("deliveryDay","Non précisé")+"\nCréneau : "+o.optString("deliveryTime","Non précisé"),14,GRAY,false));

        JSONArray history=o.optJSONArray("statusHistory");
        if(history!=null&&history.length()>0){
            box.addView(txt("\nHistorique",16,DARK,true));
            for(int i=0;i<history.length();i++){
                JSONObject h=history.optJSONObject(i);
                if(h!=null)box.addView(txt("• "+h.optString("status")+" — "+h.optString("date"),14,GRAY,false));
            }
        }
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        new AlertDialog.Builder(this).setTitle("Suivi de commande").setView(scroll).setPositiveButton("Fermer",null).show();
    }
    private void askAdminPin(){
        String saved=getSharedPreferences("fasso_admin",MODE_PRIVATE).getString("pin_hash","");
        if(saved.isEmpty()){
            LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12),0,dp(12),0);
            EditText first=new EditText(this); first.setHint("Créer un code (6 chiffres minimum)"); first.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            EditText second=new EditText(this); second.setHint("Confirmer le code"); second.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            box.addView(first); box.addView(second);
            new AlertDialog.Builder(this).setTitle("Créer l'accès administrateur").setMessage("Choisissez un code d'au moins 6 chiffres. Ne le partagez pas.").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Créer",(d,w)->{String a=first.getText().toString(), b=second.getText().toString();if(a.length()<6||!a.equals(b)){Toast.makeText(this,"Code invalide ou différent.",Toast.LENGTH_LONG).show();return;}saveAdminPin(a);startActivity(new Intent(this,AdminActivity.class));}).show();
            return;
        }
        final EditText pin=new EditText(this); pin.setHint("Code administrateur"); pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Administration privée").setMessage("Entrez votre code administrateur.").setView(pin).setNegativeButton("Annuler",null).setPositiveButton("Ouvrir",(d,w)->{String entered=pin.getText().toString();if(isAdminPinValid(entered))startActivity(new Intent(this,AdminActivity.class));else Toast.makeText(this,"Code incorrect.",Toast.LENGTH_LONG).show();}).show();
    }
    private boolean isAdminPinValid(String entered){
        if(entered.length()<6)return false;
        android.content.SharedPreferences p=getSharedPreferences("fasso_admin",MODE_PRIVATE);
        String salt=p.getString("pin_salt",""); String saved=p.getString("pin_hash","");
        if(saved.isEmpty())return false;
        if(!salt.isEmpty() && saved.equals(hashWithSalt(entered,salt)))return true;
        if(salt.isEmpty() && saved.equals(hash(entered))){
            String newSalt=java.util.UUID.randomUUID().toString();
            p.edit().putString("pin_salt",newSalt).putString("pin_hash",hashWithSalt(entered,newSalt)).apply();
            return true;
        }
        return false;
    }
    private String hash(String s){try{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");byte[] b=md.digest(s.getBytes("UTF-8"));StringBuilder h=new StringBuilder();for(byte x:b)h.append(String.format("%02x",x));return h.toString();}catch(Exception e){return "";}}
    private String hashWithSalt(String s,String salt){return hash(s+":"+salt);}
    private void saveAdminPin(String pin){String salt=java.util.UUID.randomUUID().toString();getSharedPreferences("fasso_admin",MODE_PRIVATE).edit().putString("pin_salt",salt).putString("pin_hash",hashWithSalt(pin,salt)).apply();}
    private void showQuoteDialog(){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(10),0,dp(10),0);EditText name=new EditText(this);name.setHint("Votre nom");EditText phone=new EditText(this);phone.setHint("Téléphone");phone.setInputType(InputType.TYPE_CLASS_PHONE);EditText request=new EditText(this);request.setHint("Votre demande");f.addView(name);f.addView(phone);f.addView(request);new AlertDialog.Builder(this).setTitle("Demander un devis").setView(f).setNegativeButton("Annuler",null).setPositiveButton("Envoyer",(d,w)->Toast.makeText(this,"Demande de devis enregistrée.",Toast.LENGTH_LONG).show()).show();}

    private void showGuideStep(int step) {
        final String[] titles = {"Bienvenue sur Fasso Commerce", "Rechercher un produit", "Explorer les catégories", "Ajouter au panier", "Commander et suivre", "Compte et aide"};
        final String[] messages = {
            "Bienvenue ! Ce guide vous montre les boutons et les gestes essentiels. Appuyez sur Suivant pour continuer ou Passer pour commencer directement.",
            "Touchez la barre de recherche, écrivez le nom d’un article, puis utilisez la touche de recherche du clavier. Vous pouvez revenir à l’accueil à tout moment.",
            "Faites glisser les catégories horizontalement avec le doigt. Touchez une catégorie pour filtrer les produits, ou utilisez Catégories en bas.",
            "Touchez 🛒 sur un produit pour l’ajouter. Dans le panier, utilisez − et + pour modifier la quantité avant de valider.",
            "Dans le panier, validez la commande et renseignez vos coordonnées. Orange Money n’est pas débité automatiquement dans cette version : aucun PIN n’est demandé ou enregistré.",
            "Dans Compte, retrouvez vos commandes, le suivi, l’administration privée et ce guide. Gardez votre code administrateur secret."
        };
        if (step < 0) step = 0;
        if (step >= titles.length) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("first_run_guide_seen", true).apply();
            showInfo("Guide terminé", "Vous pouvez commencer à utiliser Fasso Commerce. Retrouvez ce guide dans Compte.");
            return;
        }
        final int current = step;
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(titles[current])
                .setMessage(messages[current])
                .setNegativeButton(current == 0 ? "Passer" : "Précédent", (d, w) -> {
                    if (current == 0) {
                        getPreferences(MODE_PRIVATE).edit().putBoolean("first_run_guide_seen", true).apply();
                    } else showGuideStep(current - 1);
                })
                .setPositiveButton(current == titles.length - 1 ? "Terminer" : "Suivant", (d, w) -> {
                    if (current == titles.length - 1) {
                        getPreferences(MODE_PRIVATE).edit().putBoolean("first_run_guide_seen", true).apply();
                        showInfo("Guide terminé", "Vous pouvez retrouver ce guide dans Compte.");
                    } else showGuideStep(current + 1);
                });
        builder.show();
    }

    private void showInfo(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",null).show();}
}
