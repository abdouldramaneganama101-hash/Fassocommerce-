package com.fassocommerce;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

public class AdminActivity extends Activity {
    private static final int ORANGE=Color.rgb(255,102,0), DARK=Color.rgb(24,37,58), LIGHT=Color.rgb(248,249,251);
    private static final int PICK_PRODUCT=1001,PICK_AD=1002,PICK_VIDEO=1003;
    private final List<Uri> selectedImages=new ArrayList<>(); private Uri selectedVideo;
    private TextView photoCount,videoCount; private ImageView preview,adPreview; private LinearLayout productList,orderList;
    private EditText nameInput,priceInput,stockInput,descriptionInput,categoryInput; private int editingIndex=-1;
    @Override protected void onCreate(Bundle b){super.onCreate(b);buildScreen();}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}
    private TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(22);t.setTextColor(ORANGE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,dp(18),0,dp(10));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(bg(ORANGE,18));return b;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(16);e.setPadding(dp(12),dp(6),dp(12),dp(6));return e;}
    private void buildScreen(){ScrollView sc=new ScrollView(this);LinearLayout main=new LinearLayout(this);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(18),dp(12),dp(18),dp(35));main.setBackgroundColor(Color.WHITE);
        TextView h=title("FASSO COMMERCE — ADMINISTRATION");h.setTextSize(25);h.setGravity(Gravity.CENTER);main.addView(h);TextView info=new TextView(this);info.setText("Espace privé du propriétaire");info.setGravity(Gravity.CENTER);info.setTextSize(16);main.addView(info);
        main.addView(title("COMMANDES"));
        LinearLayout filters=new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL);
        Button all=btn("Toutes"), received=btn("Reçues"), progress=btn("En cours"), paid=btn("Payées"), unpaid=btn("Non payées");
        Button[] fs={all,received,progress,paid,unpaid}; for(Button x:fs) filters.addView(x,new LinearLayout.LayoutParams(0,dp(50),1));
        main.addView(filters); orderList=new LinearLayout(this);orderList.setOrientation(LinearLayout.VERTICAL);main.addView(orderList);
        final int[] orderFilter={0};
        View.OnClickListener fl=v->{ if(v==all)orderFilter[0]=0; else if(v==received)orderFilter[0]=1; else if(v==progress)orderFilter[0]=2; else if(v==paid)orderFilter[0]=3; else orderFilter[0]=4; refreshOrders(orderFilter[0]); };
        for(Button x:fs)x.setOnClickListener(fl); refreshOrders(0);
        main.addView(title("COMPTE BOUTIQUE"));TextView ai=new TextView(this);ai.setText("Téléphones : 55883858 / 55284612");ai.setTextSize(16);main.addView(ai);Button account=btn("👤  Gérer le compte vendeur");main.addView(account);account.setOnClickListener(v->showAccountDialog()); Button messages=btn("💬  Messages des clients"); main.addView(messages); messages.setOnClickListener(v->showMessages());
        main.addView(title("PUBLICITÉ"));adPreview=new ImageView(this);adPreview.setAdjustViewBounds(true);adPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);String ad=ProductStore.getAdvertisingUri(this);if(!ad.isEmpty())try{adPreview.setImageURI(Uri.parse(ad));}catch(Exception ignored){}main.addView(adPreview,new LinearLayout.LayoutParams(-1,dp(200)));Button addAd=btn("📢  Ajouter / modifier la publicité");main.addView(addAd);addAd.setOnClickListener(v->chooseAdvertisingPhoto());Button delAd=btn("🗑️  Supprimer la publicité");main.addView(delAd);delAd.setOnClickListener(v->confirmDeleteAd());
        main.addView(title("PRODUITS"));Button add=btn("➕  Ajouter un produit");main.addView(add);add.setOnClickListener(v->showProductForm(-1));productList=new LinearLayout(this);productList.setOrientation(LinearLayout.VERTICAL);main.addView(productList);refreshProductList();
        TextView note=new TextView(this);note.setText("\nVersion locale de test : pour que plusieurs clients reçoivent automatiquement les produits et envoient leurs commandes, une synchronisation avec un serveur sécurisé sera nécessaire.");note.setTextSize(14);main.addView(note);Button back=btn("← Retour à la boutique");main.addView(back);back.setOnClickListener(v->finish());sc.addView(main);setContentView(sc);}
    private void showAccountDialog(){SharedPreferences p=getSharedPreferences("fasso_account",MODE_PRIVATE);EditText n=field("Nom boutique"),ph=field("Téléphone"),a=field("Adresse"),pay=field("Mode de paiement / réception");n.setText(p.getString("name",""));ph.setText(p.getString("phone","55883858 / 55284612"));a.setText(p.getString("address",""));pay.setText(p.getString("payment",""));LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(n);box.addView(ph);box.addView(a);box.addView(pay);new AlertDialog.Builder(this).setTitle("Compte vendeur").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->p.edit().putString("name",n.getText().toString().trim()).putString("phone",ph.getText().toString().trim()).putString("address",a.getText().toString().trim()).putString("payment",pay.getText().toString().trim()).apply()).show();}
    private void refreshOrders(){ refreshOrders(0); }
    private void refreshOrders(int filter){
        if(orderList==null)return;
        orderList.removeAllViews();
        JSONArray os=OrderStore.getOrders(this);
        if(os.length()==0){
            TextView e=new TextView(this);e.setText("Aucune commande reçue pour le moment.");e.setTextSize(16);orderList.addView(e);return;
        }
        for(int i=0;i<os.length();i++){
            final int idx=i;
            try{
                JSONObject o=os.getJSONObject(i);
                String status=o.optString("status","Nouvelle");
                String payment=o.optString("paymentStatus","Non payé");
                if(filter==1 && !"Nouvelle".equals(status)) continue;
                if(filter==2 && !("Confirmée".equals(status)||"En préparation".equals(status)||"Prête".equals(status))) continue;
                if(filter==3 && !"Payé".equalsIgnoreCase(payment)) continue;
                if(filter==4 && "Payé".equalsIgnoreCase(payment)) continue;
                TextView t=new TextView(this);
                t.setText("Commande #"+o.optLong("id")+"\n"
                        +o.optString("product")+" × "+o.optString("quantity")+"\n"
                        +"Prix : "+o.optString("price")+"\n"
                        +"Total : "+o.optString("total",o.optString("price"))+" FCFA\n"
                        +"Client : "+o.optString("customer")+"\n"
                        +"Téléphone : "+o.optString("phone")+"\n"
                        +"Lieu : "+o.optString("address")+"\n"
                        +"Livraison : "+o.optString("deliveryDay","Non précisé")+" — "+o.optString("deliveryTime","Non précisé")+"\n"
                        +"Statut : "+o.optString("status","Nouvelle")+"\n"
                        +"Dernière mise à jour : "+o.optString("statusDate",o.optString("date",""))+"\n"
                        +"Paiement : "+o.optString("paymentMethod","Non précisé")+" — "+o.optString("paymentStatus","Non précisé"));
                t.setTextSize(15);t.setPadding(dp(12),dp(12),dp(12),dp(8));t.setBackground(bg(LIGHT,15));orderList.addView(t);
                LinearLayout actions=new LinearLayout(this);
                Button track=btn("📦 Suivi"),st=btn("Statut"),pay=btn("Paiement"),del=btn("Supprimer");
                actions.addView(track,new LinearLayout.LayoutParams(0,dp(50),1));
                actions.addView(st,new LinearLayout.LayoutParams(0,dp(50),1));
                actions.addView(pay,new LinearLayout.LayoutParams(0,dp(50),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(50),1));
                orderList.addView(actions);
                track.setOnClickListener(v->showAdminTracking(o));
                st.setOnClickListener(v->showStatusDialog(idx));
                pay.setOnClickListener(v->showPaymentStatusDialog(idx));
                del.setOnClickListener(v->confirmDeleteOrder(idx));
            }catch(Exception ignored){}
        }
    }

    private void showAdminTracking(JSONObject o){
        if(o==null)return;
        StringBuilder s=new StringBuilder();
        s.append("Commande #").append(o.optLong("id")).append("\n\n");
        s.append("Statut actuel : ").append(o.optString("status","Nouvelle")).append("\n");
        s.append("Dernière mise à jour : ").append(o.optString("statusDate",o.optString("date",""))).append("\n\n");
        JSONArray h=o.optJSONArray("statusHistory");
        if(h!=null&&h.length()>0){
            s.append("Historique du suivi :\n");
            for(int i=0;i<h.length();i++){JSONObject e=h.optJSONObject(i);if(e!=null)s.append("✓ ").append(e.optString("status")).append(" — ").append(e.optString("date")).append("\n");}
        }
        s.append("\nTotal : ").append(o.optString("total",o.optString("price","Non précisé"))).append(" FCFA");
        s.append("\nPaiement : ").append(o.optString("paymentMethod","Non précisé"));
        s.append("\nStatut paiement : ").append(o.optString("paymentStatus","Non précisé"));
        new AlertDialog.Builder(this).setTitle("Suivi de commande").setMessage(s.toString()).setPositiveButton("Fermer",null).show();
    }

    private void showPaymentStatusDialog(int i){
        String[] c={"Non payé","Payé"};
        new AlertDialog.Builder(this).setTitle("Statut du paiement").setItems(c,(d,w)->{try{OrderStore.updatePaymentStatus(this,i,c[w]);refreshOrders();}catch(Exception e){Toast.makeText(this,"Impossible de modifier le paiement.",Toast.LENGTH_LONG).show();}}).show();
    }

    private void showMessages(){
        JSONArray ms=MessageStore.getMessages(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(4),dp(10),dp(4));
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<ms.length();i++){ JSONObject m=ms.optJSONObject(i); if(m!=null) list.addView(txtAdmin(m.optString("sender","Client")+" — "+m.optString("date","")+"\n"+m.optString("text",""))); }
        if(ms.length()==0) list.addView(txtAdmin("Aucun message reçu.")); scroll.addView(list); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        EditText reply=field("Répondre au client..."); box.addView(reply); Button send=btn("Envoyer"); box.addView(send,new LinearLayout.LayoutParams(-1,dp(50)));
        send.setOnClickListener(v->{String t=reply.getText().toString().trim();if(t.isEmpty())return;try{MessageStore.add(this,"Fasso Commerce",t);reply.setText("");Toast.makeText(this,"Réponse enregistrée.",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}});
        MessageStore.markAllRead(this); new AlertDialog.Builder(this).setTitle("💬 Messages clients").setView(box).setNegativeButton("Fermer",null).show();
    }
    private TextView txtAdmin(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(15);t.setTextColor(DARK);t.setPadding(dp(10),dp(10),dp(10),dp(10));t.setBackground(bg(LIGHT,12));return t;}

    private void showStatusDialog(int i){String[] c={"Nouvelle","Confirmée","En préparation","Prête","Livrée","Annulée"};new AlertDialog.Builder(this).setTitle("Statut").setItems(c,(d,w)->{try{OrderStore.updateStatus(this,i,c[w]);refreshOrders();}catch(Exception e){Toast.makeText(this,"Impossible de modifier le statut.",Toast.LENGTH_LONG).show();}}).show();}
    private void confirmDeleteOrder(int i){new AlertDialog.Builder(this).setTitle("Supprimer la commande ?").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{OrderStore.deleteOrder(this,i);refreshOrders();}).show();}
    private void chooseAdvertisingPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_AD);}
    private void confirmDeleteAd(){if(ProductStore.getAdvertisingUri(this).isEmpty())return;new AlertDialog.Builder(this).setTitle("Supprimer la publicité ?").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{ProductStore.clearAdvertising(this);if(adPreview!=null)adPreview.setImageDrawable(null);}).show();}
    private void showProductForm(int index){editingIndex=index;selectedImages.clear();selectedVideo=null;LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);nameInput=field("Nom du produit");categoryInput=field("Catégorie (ex. Tondeuses, Compresseurs, Autres)");priceInput=field("Prix");stockInput=field("Stock");descriptionInput=field("Description");f.addView(nameInput);f.addView(categoryInput);preview=new ImageView(this);preview.setAdjustViewBounds(true);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);f.addView(preview,new LinearLayout.LayoutParams(-1,dp(280)));photoCount=new TextView(this);f.addView(photoCount);Button photos=btn("📷  Choisir plusieurs photos");f.addView(photos);photos.setOnClickListener(v->chooseProductPhoto());videoCount=new TextView(this);f.addView(videoCount);Button video=btn("▶️  Ajouter une vidéo");f.addView(video);video.setOnClickListener(v->chooseProductVideo());
        if(index>=0)try{JSONObject p=ProductStore.getProducts(this).getJSONObject(index);nameInput.setText(p.optString("name",""));priceInput.setText(p.optString("price",""));stockInput.setText(p.optString("stock",""));descriptionInput.setText(p.optString("description",""));categoryInput.setText(p.optString("category",""));JSONArray a=p.optJSONArray("imageUris");if(a!=null)for(int j=0;j<a.length();j++)if(!a.optString(j,"").isEmpty())selectedImages.add(Uri.parse(a.optString(j)));String vu=p.optString("videoUri","");if(!vu.isEmpty())selectedVideo=Uri.parse(vu);refreshPreview();}catch(Exception ignored){}else refreshPreview();
        AlertDialog d=new AlertDialog.Builder(this).setTitle(index>=0?"Modifier le produit":"Ajouter un produit").setView(f).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",null).create();d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String n=nameInput.getText().toString().trim();if(n.isEmpty()){nameInput.setError("Nom obligatoire");return;}if(selectedImages.isEmpty()){Toast.makeText(this,"Ajoute au moins une photo.",Toast.LENGTH_LONG).show();return;}try{JSONArray a=new JSONArray();for(Uri u:selectedImages)a.put(u.toString());if(index>=0)ProductStore.updateProduct(this,index,n,priceInput.getText().toString().trim(),stockInput.getText().toString().trim(),descriptionInput.getText().toString().trim(),categoryInput.getText().toString().trim(),a,selectedVideo==null?"":selectedVideo.toString());else ProductStore.addProduct(this,n,priceInput.getText().toString().trim(),stockInput.getText().toString().trim(),descriptionInput.getText().toString().trim(),categoryInput.getText().toString().trim(),a,selectedVideo==null?"":selectedVideo.toString());d.dismiss();refreshProductList();Toast.makeText(this,"Produit enregistré.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Erreur d'enregistrement.",Toast.LENGTH_LONG).show();}}));d.show();}
    private void chooseProductPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_PRODUCT);}
    private void chooseProductVideo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_VIDEO);}
    private void refreshPreview(){if(photoCount!=null)photoCount.setText(selectedImages.size()+" photo(s) sélectionnée(s)");if(videoCount!=null)videoCount.setText(selectedVideo==null?"Aucune vidéo sélectionnée":"1 vidéo sélectionnée");if(preview!=null&&!selectedImages.isEmpty())try{preview.setImageURI(selectedImages.get(0));}catch(Exception ignored){}}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(result!=RESULT_OK||data==null)return;if(r==PICK_PRODUCT){selectedImages.clear();if(data.getClipData()!=null){for(int k=0;k<data.getClipData().getItemCount();k++){Uri u=data.getClipData().getItemAt(k).getUri();selectedImages.add(u);try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}}else if(data.getData()!=null){Uri u=data.getData();selectedImages.add(u);}refreshPreview();}else if(r==PICK_VIDEO&&data.getData()!=null){selectedVideo=data.getData();try{getContentResolver().takePersistableUriPermission(selectedVideo,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}refreshPreview();Toast.makeText(this,"Vidéo sélectionnée.",Toast.LENGTH_SHORT).show();}else if(r==PICK_AD&&data.getData()!=null){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}ProductStore.setAdvertisingUri(this,u.toString());if(adPreview!=null)adPreview.setImageURI(u);}}
    private void refreshProductList(){if(productList==null)return;productList.removeAllViews();JSONArray ps=ProductStore.getProducts(this);for(int i=0;i<ps.length();i++){final int idx=i;try{JSONObject p=ps.getJSONObject(i);TextView n=new TextView(this);n.setText("📦 "+p.optString("name")+" — "+p.optString("price")+" F CFA\nCatégorie : "+p.optString("category","Autres")+"\nStock : "+p.optString("stock")+(p.optString("videoUri","").isEmpty()?"":"\n▶️ Vidéo disponible"));n.setTextSize(16);n.setPadding(dp(10),dp(10),dp(10),dp(8));productList.addView(n);LinearLayout a=new LinearLayout(this);Button e=btn("✏️ Modifier"),d=btn("🗑️ Supprimer");a.addView(e,new LinearLayout.LayoutParams(0,dp(50),1));a.addView(d,new LinearLayout.LayoutParams(0,dp(50),1));productList.addView(a);e.setOnClickListener(v->showProductForm(idx));d.setOnClickListener(v->confirmDelete(idx));}catch(Exception ignored){}}}
    private void confirmDelete(int i){new AlertDialog.Builder(this).setTitle("Supprimer le produit ?").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{ProductStore.deleteProduct(this,i);refreshProductList();}).show();}
}
