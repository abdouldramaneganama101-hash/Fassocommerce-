# Fasso Commerce V2.5 — sécurité + interface améliorée

Base: Fasso Commerce V2.4 avec guide interactif et ressources locales.

Améliorations de cette version:
- version Android 2.5 / versionCode 14
- sauvegarde Android désactivée pour limiter l’exposition des données locales
- trafic HTTP non chiffré explicitement interdit
- workflow GitHub sans recherche/décompression arbitraire de ZIP
- workflow compatible avec projet à la racine ou dans `fasso/`
- logo et images produits locaux conservés
- guide interactif conservé et accessible depuis Compte
- paiement Orange Money reste une demande en attente: aucun PIN n’est demandé ni enregistré

Le workflow doit être exécuté dans GitHub Actions pour produire l’APK.
