package com.fassocommerce;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public final class OrderStore {
    private static final String PREFS = "fasso_orders";
    private static final String KEY = "orders";
    private OrderStore() {}

    public static JSONArray getOrders(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context context, JSONArray orders) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, orders.toString()).apply();
    }

    public static void addOrder(Context context, String productName, String price, String customer,
                                String phone, String address, String quantity) throws Exception {
        addOrder(context, productName, price, customer, phone, address, quantity, "Non précisé", "Non applicable");
    }

    public static void addOrder(Context context, String productName, String price, String customer,
                                String phone, String address, String quantity, String paymentMethod, String paymentStatus) throws Exception {
        JSONArray orders = getOrders(context);
        JSONObject o = new JSONObject();
        o.put("id", System.currentTimeMillis());
        o.put("product", productName);
        o.put("price", price);
        o.put("customer", customer);
        o.put("phone", phone);
        o.put("address", address);
        o.put("quantity", quantity);
        String now = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
        o.put("status", "Nouvelle");
        o.put("statusDate", now);
        o.put("paymentMethod", paymentMethod);
        o.put("paymentStatus", paymentStatus);
        o.put("date", now);
        JSONArray history = new JSONArray();
        JSONObject first = new JSONObject();
        first.put("status", "Nouvelle");
        first.put("date", now);
        history.put(first);
        o.put("statusHistory", history);
        orders.put(o);
        save(context, orders);
    }

    public static void updateStatus(Context context, int index, String status) throws Exception {
        JSONArray orders = getOrders(context);
        if (index < 0 || index >= orders.length()) return;
        JSONObject order = orders.getJSONObject(index);
        String oldStatus = order.optString("status", "Nouvelle");
        if (oldStatus.equals(status)) return;
        String now = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
        order.put("status", status);
        order.put("statusDate", now);
        JSONArray history = order.optJSONArray("statusHistory");
        if (history == null) {
            history = new JSONArray();
            JSONObject first = new JSONObject();
            first.put("status", oldStatus);
            first.put("date", order.optString("date", now));
            history.put(first);
            order.put("statusHistory", history);
        }
        JSONObject event = new JSONObject();
        event.put("status", status);
        event.put("date", now);
        history.put(event);
        save(context, orders);
    }

    public static void deleteOrder(Context context, int index) {
        JSONArray orders = getOrders(context);
        if (index < 0 || index >= orders.length()) return;
        orders.remove(index);
        save(context, orders);
    }
}
