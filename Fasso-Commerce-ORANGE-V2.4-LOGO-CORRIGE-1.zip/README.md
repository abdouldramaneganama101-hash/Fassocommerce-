# Fasso Commerce V2.4

Version préparée pour éviter les anciens problèmes de compilation et d'images.

- Gradle 9.6.1
- Java 17
- Android SDK 36
- Logo Fasso intégré dans `res/drawable-nodpi`
- Images produits intégrées dans `res/drawable-nodpi`
- Version Android : 2.4 (versionCode 13)
- Le workflow peut compiler un projet placé directement à la racine ou un ZIP de projet.
