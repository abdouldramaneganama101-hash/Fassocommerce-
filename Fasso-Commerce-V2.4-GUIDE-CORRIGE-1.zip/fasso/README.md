# Fasso Commerce V2.4 corrigé — guide de première utilisation

Projet Android natif Java. Ouvrir/importer ce dossier comme projet Gradle Android.

## Modifications apportées
- Ajout d’un guide interactif au premier lancement (Suivant, Précédent, Passer, Terminer).
- Ajout de « Revoir le guide d’utilisation » dans Compte.
- Le choix Passer/Terminer mémorise que le guide a été vu sur cet appareil.
- Les ressources locales du logo et des produits sont conservées.

## Limites à connaître
- Les commandes et produits sont stockés localement sur le téléphone; cette archive ne met pas en place de serveur partagé.
- Orange Money n’est pas intégré en paiement automatique : le statut reste en attente de confirmation.
- Le projet n’a pas été compilé dans cet environnement faute de Gradle/SDK Android disponibles. Vérifier le résultat dans GitHub Actions avant d’installer l’APK.
