# Fasso Commerce V2.3

Version préparée pour une compilation GitHub Actions sans dépendre de `gradlew`.
Le workflow installe Gradle 9.6.1 sur le runner puis compile directement le module `app`.
