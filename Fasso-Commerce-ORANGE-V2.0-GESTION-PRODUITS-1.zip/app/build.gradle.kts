plugins {
    id("com.android.application")
}

android {
    namespace = "com.fassocommerce"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.fassocommerce"
        minSdk = 23
        targetSdk = 36
        versionCode = 10
        versionName = "1.9"
    }
}
