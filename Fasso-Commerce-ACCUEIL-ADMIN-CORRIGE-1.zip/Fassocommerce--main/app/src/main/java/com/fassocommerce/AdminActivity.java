package com.fassocommerce;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class AdminActivity extends Activity {
    private final int GREEN = Color.rgb(0, 128, 0);
    private static final int PICK_IMAGE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scrollView = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 40);
        main.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("ADMINISTRATION");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(GREEN);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        TextView info = new TextView(this);
        info.setText("Gestion privée de Fasso Commerce");
        info.setTextSize(17);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 10, 0, 25);
        main.addView(info);

        Button add = addButton(main, "➕  Ajouter un produit");
        add.setOnClickListener(v -> chooseProductPhoto());

        Button photos = addButton(main, "🖼️  Ajouter / gérer les photos");
        photos.setOnClickListener(v -> chooseProductPhoto());

        addButton(main, "✏️  Modifier les produits");
        addButton(main, "🗑️  Supprimer un produit");
        addButton(main, "💰  Gérer les prix");
        addButton(main, "📦  Gérer le stock");
        addButton(main, "📢  Gérer les publicités");
        addButton(main, "🛒  Voir les commandes");
        addButton(main, "👥  Voir les clients");
        addButton(main, "📊  Voir les ventes");

        TextView security = new TextView(this);
        security.setText("\nAccès administrateur protégé par un code local. Pour une mise en production, l'authentification devra être renforcée côté serveur.");
        security.setTextSize(14);
        security.setGravity(Gravity.CENTER);
        security.setPadding(0, 20, 0, 20);
        main.addView(security);

        Button back = new Button(this);
        back.setText("← Retour à la boutique");
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(GREEN);
        main.addView(back, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        back.setOnClickListener(v -> finish());

        scrollView.addView(main);
        setContentView(scrollView);
    }

    private Button addButton(LinearLayout main, String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setTextColor(Color.BLACK);
        button.setBackgroundColor(Color.rgb(245, 245, 245));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 10);
        main.addView(button, params);
        return button;
    }

    private void chooseProductPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri image = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(image, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            Toast.makeText(this, "Photo sélectionnée. La gestion complète du produit sera ajoutée dans l'étape suivante.", Toast.LENGTH_LONG).show();
        }
    }
}
