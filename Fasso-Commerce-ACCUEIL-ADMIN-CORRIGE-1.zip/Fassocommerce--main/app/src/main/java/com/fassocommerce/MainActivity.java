package com.fassocommerce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int DARK = Color.rgb(25, 35, 45);
    private static final int LIGHT = Color.rgb(247, 249, 248);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.WHITE);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(22, 18, 22, 35);
        main.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 10, 12, 10);
        header.setBackgroundColor(GREEN);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, new LinearLayout.LayoutParams(95, 70));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("Fasso\nCommerce");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(19);
        headerTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(headerTitle, new LinearLayout.LayoutParams(0, 70, 1));

        TextView searchIcon = new TextView(this);
        searchIcon.setText("⌕");
        searchIcon.setTextColor(Color.WHITE);
        searchIcon.setTextSize(34);
        searchIcon.setGravity(Gravity.CENTER);
        header.addView(searchIcon, new LinearLayout.LayoutParams(55, 70));

        TextView menuIcon = new TextView(this);
        menuIcon.setText("⋮");
        menuIcon.setTextColor(Color.WHITE);
        menuIcon.setTextSize(32);
        menuIcon.setGravity(Gravity.CENTER);
        menuIcon.setContentDescription("Menu");
        menuIcon.setClickable(true);
        menuIcon.setFocusable(true);
        menuIcon.setOnClickListener(v -> showMenu(menuIcon));
        header.addView(menuIcon, new LinearLayout.LayoutParams(45, 70));

        main.addView(header);

        TextView welcome = new TextView(this);
        welcome.setText("Accueil");
        welcome.setTextSize(34);
        welcome.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        welcome.setTextColor(DARK);
        welcome.setPadding(8, 28, 8, 5);
        main.addView(welcome);

        TextView subtitle = new TextView(this);
        subtitle.setText("Bienvenue chez Fasso Commerce");
        subtitle.setTextSize(20);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(8, 0, 8, 20);
        main.addView(subtitle);

        EditText search = new EditText(this);
        search.setHint("Rechercher un produit");
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setPadding(18, 8, 18, 8);
        main.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView advertising = new TextView(this);
        advertising.setText("PUBLICITÉ\n\nDécouvrez ici vos prochaines publicités et photos de produits");
        advertising.setTextSize(19);
        advertising.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        advertising.setTextColor(Color.WHITE);
        advertising.setGravity(Gravity.CENTER);
        advertising.setPadding(15, 38, 15, 38);
        advertising.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams adParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        adParams.setMargins(0, 22, 0, 25);
        main.addView(advertising, adParams);

        TextView productsTitle = new TextView(this);
        productsTitle.setText("Nos produits");
        productsTitle.setTextSize(30);
        productsTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        productsTitle.setTextColor(DARK);
        productsTitle.setPadding(8, 5, 8, 4);
        main.addView(productsTitle);

        TextView productsSubtitle = new TextView(this);
        productsSubtitle.setText("Découvrez tous nos produits");
        productsSubtitle.setTextSize(18);
        productsSubtitle.setTextColor(Color.DKGRAY);
        productsSubtitle.setPadding(8, 0, 8, 18);
        main.addView(productsSubtitle);

        LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER);
        emptyBox.setPadding(20, 55, 20, 55);
        emptyBox.setBackgroundColor(LIGHT);

        TextView boxIcon = new TextView(this);
        boxIcon.setText("▣");
        boxIcon.setTextSize(62);
        boxIcon.setTextColor(GREEN);
        boxIcon.setGravity(Gravity.CENTER);
        emptyBox.addView(boxIcon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 90));

        TextView emptyTitle = new TextView(this);
        emptyTitle.setText("Aucun produit pour le moment");
        emptyTitle.setTextSize(23);
        emptyTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        emptyTitle.setTextColor(DARK);
        emptyTitle.setGravity(Gravity.CENTER);
        emptyTitle.setPadding(0, 10, 0, 10);
        emptyBox.addView(emptyTitle);

        TextView emptyText = new TextView(this);
        emptyText.setText("Les produits seront ajoutés avec leurs photos, prix et descriptions.");
        emptyText.setTextSize(17);
        emptyText.setTextColor(Color.DKGRAY);
        emptyText.setGravity(Gravity.CENTER);
        emptyBox.addView(emptyText);

        LinearLayout.LayoutParams emptyParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        emptyParams.setMargins(0, 5, 0, 20);
        main.addView(emptyBox, emptyParams);

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(0, 10, 0, 5);
        addNavigationItem(navigation, "⌂", "Accueil", true);
        addNavigationItem(navigation, "▣", "Nos produits", false);
        addNavigationItem(navigation, "🛒", "Panier", false);
        addNavigationItem(navigation, "●", "Compte", false);
        main.addView(navigation);

        scrollView.addView(main);
        setContentView(scrollView);
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("🔐 Administration");
        popup.getMenu().add("Fermer");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle().toString().contains("Administration")) {
                openAdminProtected();
                return true;
            }
            return true;
        });
        popup.show();
    }

    private void openAdminProtected() {
        SharedPreferences prefs = getSharedPreferences("fasso_admin", MODE_PRIVATE);
        String savedHash = prefs.getString("pin_hash", "");
        if (savedHash.isEmpty()) {
            EditText pin = new EditText(this);
            pin.setHint("Créer votre code administrateur");
            pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            new AlertDialog.Builder(this)
                    .setTitle("Première utilisation")
                    .setMessage("Créez un code personnel pour protéger l'administration.")
                    .setView(pin)
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Enregistrer", (d, w) -> {
                        String value = pin.getText().toString().trim();
                        if (value.length() < 4) {
                            Toast.makeText(this, "Le code doit avoir au moins 4 chiffres.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        prefs.edit().putString("pin_hash", sha256(value)).apply();
                        startActivity(new Intent(this, AdminActivity.class));
                    }).show();
        } else {
            EditText pin = new EditText(this);
            pin.setHint("Code administrateur");
            pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            new AlertDialog.Builder(this)
                    .setTitle("Administration")
                    .setMessage("Entrez votre code administrateur.")
                    .setView(pin)
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Ouvrir", (d, w) -> {
                        if (sha256(pin.getText().toString().trim()).equals(savedHash)) {
                            startActivity(new Intent(this, AdminActivity.class));
                        } else {
                            Toast.makeText(this, "Code incorrect.", Toast.LENGTH_SHORT).show();
                        }
                    }).show();
        }
    }

    private String sha256(String value) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return value;
        }
    }

    private void addNavigationItem(LinearLayout navigation, String icon, String label, boolean selected) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(28);
        iconView.setGravity(Gravity.CENTER);
        iconView.setTextColor(selected ? GREEN : Color.GRAY);
        item.addView(iconView);
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(14);
        labelView.setGravity(Gravity.CENTER);
        labelView.setTextColor(selected ? GREEN : Color.GRAY);
        item.addView(labelView);
        navigation.addView(item, new LinearLayout.LayoutParams(0, 75, 1));
    }
}
