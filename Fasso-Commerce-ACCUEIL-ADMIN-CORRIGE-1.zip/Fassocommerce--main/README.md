# Fasso Commerce

Application Android de commerce.

La page d'accueil affiche uniquement la structure de la boutique et une section « Nos produits » vide au départ. Les produits, photos, prix, stock et publicités seront ajoutés depuis l'administration privée.

L'administration est un prototype séparé. Une authentification côté serveur devra être mise en place avant toute utilisation réelle.


Version corrigée : menu Administration cliquable et protégé par code local.
