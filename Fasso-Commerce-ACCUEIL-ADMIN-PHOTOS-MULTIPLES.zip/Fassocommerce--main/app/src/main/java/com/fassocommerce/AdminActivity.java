package com.fassocommerce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdminActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 128, 0);
    private static final int PICK_PRODUCT = 1001;
    private static final int PICK_AD = 1002;
    private Uri selectedImage;
    private final List<Uri> selectedImages = new ArrayList<>();
    private TextView photoCount;
    private ImageView preview, adPreview;
    private EditText nameInput, priceInput, stockInput, descriptionInput;
    private int editingIndex = -1;
    private LinearLayout productList, orderList;

    @Override protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); buildScreen(); }

    private void buildScreen() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL); main.setPadding(22,22,22,40); main.setBackgroundColor(Color.WHITE);
        TextView title = sectionTitle("ADMINISTRATION"); title.setTextSize(28); title.setGravity(Gravity.CENTER); main.addView(title);
        TextView info = new TextView(this); info.setText("Espace privé du propriétaire — produits, publicité, commandes et compte"); info.setTextSize(17); info.setGravity(Gravity.CENTER); info.setPadding(0,8,0,24); main.addView(info);

        main.addView(sectionTitle("COMMANDES REÇUES"));
        TextView orderInfo = new TextView(this); orderInfo.setText("Toutes les commandes envoyées depuis la boutique apparaissent ici."); orderInfo.setTextSize(16); orderInfo.setPadding(0,0,0,12); main.addView(orderInfo);
        orderList = new LinearLayout(this); orderList.setOrientation(LinearLayout.VERTICAL); main.addView(orderList);
        refreshOrders();

        main.addView(sectionTitle("COMPTE BOUTIQUE"));
        TextView accountInfo = new TextView(this); accountInfo.setText("Informations utilisées pour recevoir et gérer les commandes."); accountInfo.setTextSize(16); accountInfo.setPadding(0,0,0,8); main.addView(accountInfo);
        Button account = addButton(main,"👤  Gérer le compte vendeur"); account.setOnClickListener(v -> showAccountDialog());

        main.addView(sectionTitle("PUBLICITÉ"));
        adPreview = new ImageView(this); adPreview.setAdjustViewBounds(true); adPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String currentAd=ProductStore.getAdvertisingUri(this); if(!currentAd.isEmpty()){try{adPreview.setImageURI(Uri.parse(currentAd));}catch(Exception ignored){}} else adPreview.setBackgroundColor(Color.rgb(235,240,236));
        main.addView(adPreview,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,280));
        Button chooseAd=addButton(main,"📢  Ajouter / modifier la publicité"); chooseAd.setOnClickListener(v->chooseAdvertisingPhoto());
        Button removeAd=addButton(main,"🗑️  Supprimer la publicité"); removeAd.setOnClickListener(v->confirmDeleteAd());

        main.addView(sectionTitle("PRODUITS"));
        Button add=addButton(main,"➕  Ajouter un produit avec une grande photo"); add.setOnClickListener(v->showProductForm(-1));
        TextView listTitle=new TextView(this); listTitle.setText("Produits enregistrés"); listTitle.setTextSize(22); listTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD); listTitle.setTextColor(GREEN); listTitle.setPadding(0,10,0,10); main.addView(listTitle);
        productList=new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); main.addView(productList);
        refreshProductList();

        TextView security=new TextView(this); security.setText("\nCette administration est une version locale de test. Pour une vraie boutique en ligne, les commandes devront être synchronisées avec un serveur sécurisé."); security.setTextSize(14); security.setGravity(Gravity.CENTER); security.setPadding(0,20,0,20); main.addView(security);
        Button back=new Button(this); back.setText("← Retour à la boutique"); back.setTextColor(Color.WHITE); back.setBackgroundColor(GREEN); main.addView(back,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)); back.setOnClickListener(v->finish());
        scrollView.addView(main); setContentView(scrollView);
    }

    private TextView sectionTitle(String value){TextView t=new TextView(this);t.setText(value);t.setTextSize(22);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setTextColor(GREEN);t.setPadding(0,18,0,10);return t;}
    private Button addButton(LinearLayout main,String value){Button b=new Button(this);b.setText(value);b.setTextSize(16);b.setTextColor(Color.BLACK);b.setBackgroundColor(Color.rgb(245,245,245));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,0,0,10);main.addView(b,p);return b;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setPadding(14,9,14,9);return e;}

    private void showAccountDialog(){
        android.content.SharedPreferences p=getSharedPreferences("fasso_account",MODE_PRIVATE);
        EditText name=field("Nom du compte / boutique"); EditText phone=field("Téléphone pour recevoir les commandes"); phone.setInputType(3); EditText address=field("Adresse / lieu de réception"); EditText payment=field("Mode de paiement / compte de réception");
        name.setText(p.getString("name","")); phone.setText(p.getString("phone","")); address.setText(p.getString("address","")); payment.setText(p.getString("payment",""));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(name);box.addView(phone);box.addView(address);box.addView(payment);
        new AlertDialog.Builder(this).setTitle("Compte vendeur").setMessage("Ces informations servent à organiser la réception et le suivi des commandes.").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->p.edit().putString("name",name.getText().toString().trim()).putString("phone",phone.getText().toString().trim()).putString("address",address.getText().toString().trim()).putString("payment",payment.getText().toString().trim()).apply()).show();
    }

    private void refreshOrders(){
        if(orderList==null)return; orderList.removeAllViews(); JSONArray orders=OrderStore.getOrders(this);
        if(orders.length()==0){TextView e=new TextView(this);e.setText("Aucune commande reçue pour le moment.");e.setTextSize(17);e.setPadding(8,8,8,22);orderList.addView(e);return;}
        for(int i=0;i<orders.length();i++){final int index=i;try{JSONObject o=orders.getJSONObject(i);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(14,14,14,14);card.setBackgroundColor(Color.rgb(247,249,248));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);cp.setMargins(0,0,0,14);
            TextView t=new TextView(this);t.setText("Commande #"+o.optLong("id")+"\n"+o.optString("product")+" × "+o.optString("quantity")+"\nPrix : "+o.optString("price")+"\nClient : "+o.optString("customer")+"\nTéléphone : "+o.optString("phone")+"\nLieu : "+o.optString("address")+"\nDate : "+o.optString("date")+"\nStatut : "+o.optString("status"));t.setTextSize(16);card.addView(t);
            LinearLayout actions=new LinearLayout(this); Button status=new Button(this);status.setText("Changer statut");status.setOnClickListener(v->showStatusDialog(index)); Button del=new Button(this);del.setText("Supprimer");del.setOnClickListener(v->confirmDeleteOrder(index));actions.addView(status,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));actions.addView(del,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));card.addView(actions);orderList.addView(card,cp);}catch(Exception ignored){}}
    }
    private void showStatusDialog(int index){String[] choices={"Nouvelle","Confirmée","En préparation","Prête","Livrée","Annulée"};new AlertDialog.Builder(this).setTitle("Statut de la commande").setItems(choices,(d,w)->{try{OrderStore.updateStatus(this,index,choices[w]);refreshOrders();}catch(Exception ignored){}}).show();}
    private void confirmDeleteOrder(int index){new AlertDialog.Builder(this).setTitle("Supprimer la commande ?").setMessage("Elle sera retirée de cet appareil.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{OrderStore.deleteOrder(this,index);refreshOrders();}).show();}

    private void chooseAdvertisingPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_AD);}
    private void confirmDeleteAd(){if(ProductStore.getAdvertisingUri(this).isEmpty()){Toast.makeText(this,"Aucune publicité à supprimer.",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("Supprimer la publicité ?").setMessage("La publicité sera retirée de l'accueil sur ce téléphone.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{ProductStore.clearAdvertising(this);if(adPreview!=null){adPreview.setImageDrawable(null);adPreview.setBackgroundColor(Color.rgb(235,240,236));}Toast.makeText(this,"Publicité supprimée.",Toast.LENGTH_SHORT).show();}).show();}

    private void showProductForm(int index){editingIndex=index;selectedImage=null;selectedImages.clear();LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);nameInput=field("Nom du produit");priceInput=field("Prix");stockInput=field("Stock");descriptionInput=field("Description du produit");form.addView(nameInput);form.addView(priceInput);form.addView(stockInput);form.addView(descriptionInput);HorizontalScrollView photoScroll=new HorizontalScrollView(this);
        LinearLayout photoRow=new LinearLayout(this); photoRow.setOrientation(LinearLayout.HORIZONTAL); photoScroll.addView(photoRow);
        preview=new ImageView(this); preview.setAdjustViewBounds(true); preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photoRow.addView(preview,new LinearLayout.LayoutParams(520,300)); form.addView(photoScroll);
        photoCount=new TextView(this); photoCount.setText("0 photo sélectionnée"); photoCount.setTextSize(15); form.addView(photoCount);
        Button choose=new Button(this); choose.setText("📷 Choisir plusieurs photos à la fois"); choose.setOnClickListener(v->chooseProductPhoto()); form.addView(choose);
        if(index>=0)try{JSONObject p=ProductStore.getProducts(this).getJSONObject(index);nameInput.setText(p.optString("name",""));priceInput.setText(p.optString("price",""));stockInput.setText(p.optString("stock",""));descriptionInput.setText(p.optString("description",""));JSONArray photos=p.optJSONArray("imageUris");if(photos!=null){for(int j=0;j<photos.length();j++){String u=photos.optString(j,"");if(!u.isEmpty())selectedImages.add(Uri.parse(u));}}else{String u=p.optString("imageUri","");if(!u.isEmpty())selectedImages.add(Uri.parse(u));}refreshPhotoPreview();}catch(Exception ignored){}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(index>=0?"Modifier le produit":"Ajouter un produit").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",null).create();dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String name=nameInput.getText().toString().trim(),price=priceInput.getText().toString().trim(),stock=stockInput.getText().toString().trim(),description=descriptionInput.getText().toString().trim();if(name.isEmpty()){nameInput.setError("Nom obligatoire");return;}if(selectedImages.isEmpty()){Toast.makeText(this,"Choisis au moins une photo du produit.",Toast.LENGTH_LONG).show();return;}try{JSONArray photos=new JSONArray();for(Uri u:selectedImages)photos.put(u.toString());if(editingIndex>=0){ProductStore.updateProduct(this,editingIndex,name,price,stock,description,photos);Toast.makeText(this,"Produit modifié avec "+selectedImages.size()+" photo(s).",Toast.LENGTH_SHORT).show();}else{ProductStore.addProduct(this,name,price,stock,description,photos);Toast.makeText(this,"Produit ajouté avec "+selectedImages.size()+" photo(s).",Toast.LENGTH_LONG).show();}dialog.dismiss();refreshProductList();}catch(Exception e){Toast.makeText(this,"Impossible d'enregistrer le produit.",Toast.LENGTH_LONG).show();}}));dialog.show();}
    private void chooseProductPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_PRODUCT);}
    private void refreshPhotoPreview(){if(photoCount!=null)photoCount.setText(selectedImages.size()+" photo(s) sélectionnée(s)");if(preview!=null && !selectedImages.isEmpty()){try{preview.setImageURI(selectedImages.get(0));}catch(Exception ignored){}}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null)return;if(requestCode==PICK_PRODUCT){selectedImages.clear();if(data.getClipData()!=null){for(int k=0;k<data.getClipData().getItemCount();k++){Uri uri=data.getClipData().getItemAt(k).getUri();selectedImages.add(uri);try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}}else if(data.getData()!=null){Uri uri=data.getData();selectedImages.add(uri);try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}refreshPhotoPreview();Toast.makeText(this,selectedImages.size()+" photo(s) sélectionnée(s). Appuie sur Enregistrer.",Toast.LENGTH_LONG).show();}else if(requestCode==PICK_AD && data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}ProductStore.setAdvertisingUri(this,uri.toString());if(adPreview!=null)adPreview.setImageURI(uri);Toast.makeText(this,"Publicité enregistrée. Elle apparaît sur l'accueil.",Toast.LENGTH_LONG).show();}}
    private void refreshProductList(){if(productList==null)return;productList.removeAllViews();JSONArray products=ProductStore.getProducts(this);if(products.length()==0){TextView e=new TextView(this);e.setText("Aucun produit enregistré.");e.setTextSize(16);e.setPadding(5,10,5,20);productList.addView(e);return;}for(int i=0;i<products.length();i++){final int index=i;try{JSONObject p=products.getJSONObject(i);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(12,12,12,12);row.setBackgroundColor(Color.rgb(247,249,248));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.setMargins(0,0,0,14);JSONArray photos=p.optJSONArray("imageUris");if(photos==null){photos=new JSONArray();String legacy=p.optString("imageUri","");if(!legacy.isEmpty())photos.put(legacy);}if(photos.length()>0){HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout gallery=new LinearLayout(this);gallery.setOrientation(LinearLayout.HORIZONTAL);for(int j=0;j<photos.length();j++){String image=photos.optString(j,"");if(!image.isEmpty()){ImageView img=new ImageView(this);img.setAdjustViewBounds(true);img.setScaleType(ImageView.ScaleType.CENTER_CROP);try{img.setImageURI(Uri.parse(image));}catch(Exception ignored){}LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(420,260);ip.setMargins(0,0,12,0);gallery.addView(img,ip);}}hs.addView(gallery);row.addView(hs,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,270));}TextView name=new TextView(this);name.setText(p.optString("name","Produit")+" — "+p.optString("price","Prix non défini"));name.setTextSize(18);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(name);TextView stock=new TextView(this);stock.setText("Stock : "+p.optString("stock","0"));row.addView(stock);LinearLayout actions=new LinearLayout(this);Button edit=new Button(this);edit.setText("✏️ Modifier");edit.setOnClickListener(v->showProductForm(index));Button delete=new Button(this);delete.setText("🗑️ Supprimer");delete.setOnClickListener(v->confirmDelete(index));actions.addView(edit,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));actions.addView(delete,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));row.addView(actions);productList.addView(row,rp);}catch(Exception ignored){}}}
    private void confirmDelete(int index){new AlertDialog.Builder(this).setTitle("Supprimer le produit ?").setMessage("Le produit sera retiré de la boutique sur ce téléphone.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{ProductStore.deleteProduct(this,index);refreshProductList();Toast.makeText(this,"Produit supprimé.",Toast.LENGTH_SHORT).show();}).show();}
}
