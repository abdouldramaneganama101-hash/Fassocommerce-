package com.fassocommerce;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AdminActivity extends Activity {

    private final int GREEN = Color.rgb(0, 128, 0);
    private final int YELLOW = Color.rgb(245, 190, 0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 40);
        main.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("ADMINISTRATION");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(GREEN);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        TextView info = new TextView(this);
        info.setText("Gestion de Fasso Commerce");
        info.setTextSize(17);
        info.setTextColor(Color.DKGRAY);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 10, 0, 25);
        main.addView(info);

        addAdminButton(main, "➕  Ajouter un produit");
        addAdminButton(main, "✏️  Modifier les produits");
        addAdminButton(main, "🗑️  Supprimer un produit");
        addAdminButton(main, "🖼️  Gérer les photos");
        addAdminButton(main, "💰  Gérer les prix");
        addAdminButton(main, "📦  Gérer le stock");
        addAdminButton(main, "📢  Gérer les publicités");
        addAdminButton(main, "🛒  Voir les commandes");
        addAdminButton(main, "👥  Voir les clients");
        addAdminButton(main, "📊  Voir les ventes");

        TextView security = new TextView(this);
        security.setText("\nPrototype d'administration : une authentification sécurisée côté serveur sera ajoutée avant la mise en production.");
        security.setTextSize(14);
        security.setTextColor(Color.DKGRAY);
        security.setGravity(Gravity.CENTER);
        security.setPadding(0, 20, 0, 20);
        main.addView(security);

        Button back = new Button(this);
        back.setText("← Retour à la boutique");
        back.setTextSize(16);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(GREEN);
        main.addView(back, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        back.setOnClickListener(v -> finish());

        scrollView.addView(main);
        setContentView(scrollView);
    }

    private void addAdminButton(LinearLayout main, String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setTextColor(Color.BLACK);
        button.setBackgroundColor(Color.rgb(245, 245, 245));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 10);
        main.addView(button, params);
    }
}
