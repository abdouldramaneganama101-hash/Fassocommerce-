package com.fassocommerce;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private final int GREEN = Color.rgb(0, 128, 0);
    private final int YELLOW = Color.rgb(245, 190, 0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 40);
        main.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.fasso_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 210);
        logoParams.setMargins(0, 0, 0, 8);
        main.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("FASSO COMMERCE");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(GREEN);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        TextView slogan = new TextView(this);
        slogan.setText("Votre boutique de matériel");
        slogan.setTextSize(17);
        slogan.setTextColor(Color.DKGRAY);
        slogan.setGravity(Gravity.CENTER);
        slogan.setPadding(0, 8, 0, 25);
        main.addView(slogan);

        EditText search = new EditText(this);
        search.setHint("Rechercher un produit");
        search.setTextSize(17);
        search.setSingleLine(true);
        search.setPadding(20, 10, 20, 10);
        main.addView(search, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView advertising = new TextView(this);
        advertising.setText("PUBLICITÉ\n\nDécouvrez nos nouveaux produits");
        advertising.setTextSize(20);
        advertising.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        advertising.setTextColor(Color.WHITE);
        advertising.setGravity(Gravity.CENTER);
        advertising.setPadding(15, 35, 15, 35);
        advertising.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams adParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        adParams.setMargins(0, 25, 0, 25);
        main.addView(advertising, adParams);

        TextView productsTitle = new TextView(this);
        productsTitle.setText("Nos produits");
        productsTitle.setTextSize(24);
        productsTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        productsTitle.setTextColor(Color.BLACK);
        productsTitle.setPadding(0, 10, 0, 15);
        main.addView(productsTitle);

        addProduct(main, "🛠️  Tondeuse", "Matériel de jardinage");
        addProduct(main, "👔  Fer à repasser", "Petit matériel domestique");
        addProduct(main, "🚗  Aspirateur de véhicule", "Petit équipement automobile");
        addProduct(main, "🔧  Petit compresseur", "Matériel et équipement");
        addProduct(main, "🧯  Extincteur", "Équipement de sécurité");
        addProduct(main, "🔌  Rallonge électrique", "Accessoires et matériel");

        Button cartButton = new Button(this);
        cartButton.setText("🛒  Voir mon panier");
        cartButton.setTextSize(17);
        cartButton.setTextColor(Color.WHITE);
        cartButton.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams cartParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cartParams.setMargins(0, 25, 0, 10);
        main.addView(cartButton, cartParams);

        Button ordersButton = new Button(this);
        ordersButton.setText("📦  Mes commandes");
        ordersButton.setTextSize(17);
        main.addView(ordersButton);

        Button adminButton = new Button(this);
        adminButton.setText("🔐  Administration");
        adminButton.setTextSize(17);
        adminButton.setTextColor(Color.WHITE);
        adminButton.setBackgroundColor(YELLOW);
        LinearLayout.LayoutParams adminParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        adminParams.setMargins(0, 15, 0, 10);
        main.addView(adminButton, adminParams);
        adminButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AdminActivity.class)));

        TextView footer = new TextView(this);
        footer.setText("\nFasso Commerce\n\nAchetez facilement et suivez vos commandes.");
        footer.setTextSize(15);
        footer.setGravity(Gravity.CENTER);
        footer.setTextColor(Color.GRAY);
        footer.setPadding(0, 30, 0, 10);
        main.addView(footer);

        scrollView.addView(main);
        setContentView(scrollView);
    }

    private void addProduct(LinearLayout main, String name, String description) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 18, 20, 18);
        card.setBackgroundColor(Color.rgb(248, 248, 248));

        TextView productName = new TextView(this);
        productName.setText(name);
        productName.setTextSize(20);
        productName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        productName.setTextColor(GREEN);

        TextView productDescription = new TextView(this);
        productDescription.setText(description);
        productDescription.setTextSize(15);
        productDescription.setTextColor(Color.DKGRAY);
        productDescription.setPadding(0, 8, 0, 12);

        Button viewButton = new Button(this);
        viewButton.setText("Voir le produit");

        card.addView(productName);
        card.addView(productDescription);
        card.addView(viewButton);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 15);
        main.addView(card, params);
    }
}
