# Fasso Commerce V2.6

Améliorations incluses :
- commandes reçues, en cours, payées et non payées dans l’administration ;
- changement sécurisé du statut de paiement (Non payé / Payé) ;
- messagerie intégrée côté client et boîte de réception côté administration ;
- suivi des commandes conservé ;
- interface de paiement Orange Money préparée sans jamais demander ni stocker de PIN ;
- conservation du logo et des ressources locales ;
- guide interactif conservé.

## Paiement Orange Money
Le paiement réel dans l’application nécessite l’activation du service Orange Money Paiement en ligne / API auprès d’Orange Money Burkina Faso et un backend HTTPS pour protéger les identifiants marchands. Cette version ne simule pas un paiement et ne stocke aucun secret.

## Messagerie
Le stockage des messages présent ici fonctionne en mode local/offline. Pour que des clients sur des téléphones différents puissent réellement écrire au vendeur et recevoir ses réponses, il faut connecter cette interface à un backend sécurisé (HTTPS + authentification + base de données).
