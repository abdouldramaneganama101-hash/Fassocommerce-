package com.fassocommerce;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

/** Local message store used by the demo/offline build.
 * Cross-device customer/vendor messaging requires a secure HTTPS backend.
 */
public final class MessageStore {
    private static final String PREFS = "fasso_messages";
    private static final String KEY = "messages";
    private MessageStore() {}

    public static JSONArray getMessages(Context c) {
        String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    public static void add(Context c, String sender, String text) throws Exception {
        JSONArray a = getMessages(c);
        JSONObject m = new JSONObject();
        m.put("id", System.currentTimeMillis());
        m.put("sender", sender);
        m.put("text", text);
        m.put("date", new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()));
        m.put("read", false);
        a.put(m);
        save(c, a);
    }

    public static void markAllRead(Context c) {
        JSONArray a = getMessages(c);
        for (int i=0;i<a.length();i++) {
            JSONObject m=a.optJSONObject(i);
            if(m!=null) m.put("read", true);
        }
        save(c,a);
    }

    public static int unreadCount(Context c) {
        JSONArray a=getMessages(c); int n=0;
        for(int i=0;i<a.length();i++){ JSONObject m=a.optJSONObject(i); if(m!=null && !m.optBoolean("read",false)) n++; }
        return n;
    }
}
