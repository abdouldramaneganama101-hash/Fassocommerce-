package com.fassocommerce;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ProductStore {
    private static final String PREFS = "fasso_products";
    private static final String KEY = "items";
    private static final String AD_KEY = "advertising_uri";
    private ProductStore() {}

    public static JSONArray getProducts(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }
    public static void saveProducts(Context context, JSONArray products) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, products.toString()).apply();
    }
    public static void addProduct(Context c,String name,String price,String stock,String description,String imageUri) throws Exception {
        JSONArray photos=new JSONArray(); if(imageUri!=null&&!imageUri.isEmpty()) photos.put(imageUri);
        addProduct(c,name,price,stock,description,photos,"");
    }
    public static void updateProduct(Context c,int index,String name,String price,String stock,String description,String imageUri) throws Exception {
        JSONArray photos=new JSONArray(); if(imageUri!=null&&!imageUri.isEmpty()) photos.put(imageUri);
        updateProduct(c,index,name,price,stock,description,photos,"");
    }
    public static void addProduct(Context c,String name,String price,String stock,String description,JSONArray imageUris) throws Exception { addProduct(c,name,price,stock,description,"",imageUris,""); }
    public static void addProduct(Context c,String name,String price,String stock,String description,JSONArray imageUris,String videoUri) throws Exception { addProduct(c,name,price,stock,description,"",imageUris,videoUri); }
    public static void addProduct(Context c,String name,String price,String stock,String description,String category,JSONArray imageUris,String videoUri) throws Exception {
        JSONArray products=getProducts(c); JSONObject item=new JSONObject();
        item.put("id",System.currentTimeMillis()); item.put("name",name); item.put("price",price); item.put("stock",stock); item.put("description",description); item.put("category",category==null?"":category);
        JSONArray photos=imageUris==null?new JSONArray():imageUris; item.put("imageUris",photos); item.put("imageUri",photos.length()>0?photos.optString(0,""):""); item.put("videoUri",videoUri==null?"":videoUri);
        products.put(item); saveProducts(c,products);
    }
    public static void updateProduct(Context c,int index,String name,String price,String stock,String description,JSONArray imageUris) throws Exception { updateProduct(c,index,name,price,stock,description,"",imageUris,""); }
    public static void updateProduct(Context c,int index,String name,String price,String stock,String description,JSONArray imageUris,String videoUri) throws Exception { updateProduct(c,index,name,price,stock,description,"",imageUris,videoUri); }
    public static void updateProduct(Context c,int index,String name,String price,String stock,String description,String category,JSONArray imageUris,String videoUri) throws Exception {
        JSONArray products=getProducts(c); if(index<0||index>=products.length())return; JSONObject item=products.getJSONObject(index);
        item.put("name",name); item.put("price",price); item.put("stock",stock); item.put("description",description); item.put("category",category==null?"":category);
        JSONArray photos=imageUris==null?new JSONArray():imageUris; item.put("imageUris",photos); item.put("imageUri",photos.length()>0?photos.optString(0,""):""); item.put("videoUri",videoUri==null?"":videoUri);
        saveProducts(c,products);
    }
    public static void deleteProduct(Context c,int index){JSONArray p=getProducts(c);if(index>=0&&index<p.length()){p.remove(index);saveProducts(c,p);}}
    public static String getAdvertisingUri(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(AD_KEY,"");}
    public static void setAdvertisingUri(Context c,String uri){c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(AD_KEY,uri==null?"":uri).apply();}
    public static void clearAdvertising(Context c){c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove(AD_KEY).apply();}
}
