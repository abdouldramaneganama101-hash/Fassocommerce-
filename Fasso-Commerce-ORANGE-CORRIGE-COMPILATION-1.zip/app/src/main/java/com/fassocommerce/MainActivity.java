package com.fassocommerce;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int ORANGE = Color.rgb(255,102,0);
    private static final int DARK = Color.rgb(24,37,58);
    private static final int GRAY = Color.rgb(92,105,124);
    private static final int LIGHT = Color.rgb(248,249,251);
    private LinearLayout catalog;

    @Override protected void onCreate(Bundle b) { super.onCreate(b); buildScreen(); }
    @Override protected void onResume() { super.onResume(); if (catalog != null) loadCatalog(); }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView txt(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private Button orangeButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(rounded(ORANGE, 18)); b.setPadding(dp(10),0,dp(10),0); return b;
    }
    private ImageView image(int res, int w, int h) {
        ImageView v = new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(rounded(Color.WHITE, 16)); v.setAdjustViewBounds(true);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),dp(h))); return v;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(18));

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.fasso_logo_orange);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER); logo.setAdjustViewBounds(true);
        header.addView(logo,new LinearLayout.LayoutParams(dp(205),dp(92)));
        LinearLayout.LayoutParams spacer = new LinearLayout.LayoutParams(0,1,1); header.addView(new Space(this),spacer);
        Button bell = orangeButton("🔔"); bell.setTextSize(19); header.addView(bell,new LinearLayout.LayoutParams(dp(50),dp(50)));
        Button cart = orangeButton("🛒 0"); cart.setTextSize(15); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(82),dp(50));cp.setMargins(dp(7),0,0,0);header.addView(cart,cp);
        cart.setOnClickListener(v->Toast.makeText(this,"Panier vide",Toast.LENGTH_SHORT).show());
        root.addView(header);

        EditText search = new EditText(this); search.setHint("🔎  Rechercher un produit..."); search.setTextSize(17);
        search.setSingleLine(true); search.setPadding(dp(16),0,dp(12),0); search.setBackground(rounded(Color.rgb(245,246,248),28));
        LinearLayout.LayoutParams sr=new LinearLayout.LayoutParams(-1,dp(58));sr.setMargins(0,dp(5),0,dp(10));root.addView(search,sr);

        HorizontalScrollView tabScroll=new HorizontalScrollView(this);tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=new LinearLayout(this); tabs.setPadding(0,dp(2),0,dp(4));
        String[] tabNames={"⌂  Accueil","▦  Produits","▢  Catégories","▥  Fabricants","◎  Mondial"};
        for(int i=0;i<tabNames.length;i++){TextView t=txt(tabNames[i],15,i==0?Color.WHITE:DARK,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(18),0,dp(18),0);t.setBackground(rounded(i==0?ORANGE:Color.WHITE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(52));p.setMargins(dp(2),0,dp(5),0);tabs.addView(t,p);final int idx=i;t.setOnClickListener(v->Toast.makeText(this,tabNames[idx],Toast.LENGTH_SHORT).show());}
        tabScroll.addView(tabs);root.addView(tabScroll);

        HorizontalScrollView catScroll=new HorizontalScrollView(this);catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout cats=new LinearLayout(this);cats.setPadding(0,dp(12),0,dp(8));
        addCategory(cats,R.drawable.tondeuse,"Tondeuses");
        addCategory(cats,R.drawable.fer_repasser,"Fer à repasser");
        addCategory(cats,R.drawable.aspirateur_voiture,"Aspirateurs\nvoiture");
        addCategory(cats,R.drawable.compresseur,"Compresseurs");
        addCategory(cats,R.drawable.outillage,"Outillage");
        addCategoryPlaceholder(cats,"•••","Autres");
        catScroll.addView(cats);root.addView(catScroll);

        LinearLayout services=new LinearLayout(this); services.setOrientation(LinearLayout.HORIZONTAL); services.setPadding(dp(10),dp(8),dp(10),dp(8));
        services.setBackground(rounded(Color.rgb(255,244,237),18));
        LinearLayout delivery=serviceBox("🚚","Livraison","Rapide et fiable",false);LinearLayout quote=serviceBox("▤","Demander un devis","Gratuit et sans engagement",true);
        services.addView(delivery,new LinearLayout.LayoutParams(0,dp(90),1));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(90),1);qp.setMargins(dp(8),0,0,0);services.addView(quote,qp);
        quote.setOnClickListener(v->showQuoteDialog()); root.addView(services);

        LinearLayout title=new LinearLayout(this);title.setGravity(Gravity.CENTER_VERTICAL);title.setPadding(dp(5),dp(12),dp(5),dp(5));
        TextView top=txt("Top ventes",25,DARK,true);title.addView(top,new LinearLayout.LayoutParams(0,dp(55),1));TextView all=txt("Voir tout  ›",16,ORANGE,true);title.addView(all);root.addView(title);

        catalog=new LinearLayout(this);catalog.setOrientation(LinearLayout.VERTICAL);root.addView(catalog);
        addBottomNav(root);
        scroll.addView(root);setContentView(scroll);loadCatalog();
    }

    private void addCategory(LinearLayout parent,int res,String name){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(7),dp(7),dp(7),dp(5));box.setBackground(rounded(Color.rgb(248,249,251),16));ImageView im=image(res,105,92);box.addView(im);TextView t=txt(name,14,DARK,true);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(5),0,0);box.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(138),dp(178));p.setMargins(0,0,dp(8),0);parent.addView(box,p);}
    private void addCategoryPlaceholder(LinearLayout parent,String icon,String name){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setBackground(rounded(Color.rgb(248,249,251),16));TextView i=txt(icon,28,GRAY,true);i.setGravity(Gravity.CENTER);box.addView(i,new LinearLayout.LayoutParams(-1,dp(110)));TextView t=txt(name,14,DARK,true);t.setGravity(Gravity.CENTER);box.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(118),dp(178));p.setMargins(0,0,dp(8),0);parent.addView(box,p);}
    private LinearLayout serviceBox(String icon,String title,String sub,boolean orange){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.HORIZONTAL);b.setGravity(Gravity.CENTER_VERTICAL);b.setPadding(dp(8),dp(5),dp(8),dp(5));b.setBackground(rounded(orange?ORANGE:Color.rgb(255,239,229),16));TextView ic=txt(icon,32,orange?Color.WHITE:ORANGE,true);ic.setGravity(Gravity.CENTER);b.addView(ic,new LinearLayout.LayoutParams(dp(52),-1));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView a=txt(title,17,orange?Color.WHITE:DARK,true);TextView c=txt(sub,12,orange?Color.WHITE:GRAY,false);tx.addView(a);tx.addView(c);b.addView(tx);return b;}

    private void loadCatalog(){
        if(catalog==null)return; catalog.removeAllViews();
        addProductCard(R.drawable.tondeuse,"Tondeuse thermique","125 000 FCFA",12);
        addProductCard(R.drawable.fer_repasser,"Fer à repasser","15 500 FCFA",8);
        addProductCard(R.drawable.aspirateur_voiture,"Aspirateur voiture","12 000 FCFA",6);
        JSONArray ps=ProductStore.getProducts(this);
        for(int i=0;i<ps.length();i++){try{JSONObject p=ps.getJSONObject(i);addStoredProductCard(p);}catch(Exception ignored){}}
    }
    private void addProductCard(int res,String name,String price,int reviews){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(rounded(Color.WHITE,18));
        ImageView im=image(res,150,120);card.addView(im);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(4),0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView n=txt(name,18,DARK,true);info.addView(n);TextView stars=txt("★★★★★  ("+reviews+")",14,ORANGE,true);stars.setPadding(0,dp(6),0,dp(4));info.addView(stars);TextView pr=txt(price,18,ORANGE,true);info.addView(pr);
        Button b=orangeButton("🛒");b.setTextSize(20);card.addView(b,new LinearLayout.LayoutParams(dp(55),dp(55)));b.setOnClickListener(v->Toast.makeText(this,name+" ajouté au panier",Toast.LENGTH_SHORT).show());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(142));cp.setMargins(0,0,0,dp(10));catalog.addView(card,cp);
    }
    private void addStoredProductCard(JSONObject p){
        String name=p.optString("name","Produit");String price=p.optString("price","Prix à préciser");String uri=p.optString("imageUri","");
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(rounded(Color.WHITE,18));
        ImageView im=new ImageView(this);im.setBackground(rounded(Color.WHITE,16));im.setScaleType(ImageView.ScaleType.CENTER_CROP);if(!uri.isEmpty())try{im.setImageURI(android.net.Uri.parse(uri));}catch(Exception ignored){}card.addView(im,new LinearLayout.LayoutParams(dp(150),dp(120)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(4),0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));info.addView(txt(name,18,DARK,true));info.addView(txt("Nouveau produit",14,GRAY,false));info.addView(txt(price+" FCFA",18,ORANGE,true));Button b=orangeButton("🛒");card.addView(b,new LinearLayout.LayoutParams(dp(55),dp(55)));b.setOnClickListener(v->Toast.makeText(this,name+" ajouté au panier",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(142));cp.setMargins(0,0,0,dp(10));catalog.addView(card,cp);
    }

    private void addBottomNav(LinearLayout root){LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(0,dp(10),0,0);String[] items={"⌂\nAccueil","▦\nCatégories","💬\nMessagerie","🛒\nPanier","♙\nCompte"};for(int i=0;i<items.length;i++){TextView t=txt(items[i],13,i==0?ORANGE:DARK,i==0);t.setGravity(Gravity.CENTER);nav.addView(t,new LinearLayout.LayoutParams(0,dp(70),1));}root.addView(nav);}

    private void showQuoteDialog(){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(10),0,dp(10),0);EditText name=new EditText(this);name.setHint("Votre nom");EditText phone=new EditText(this);phone.setHint("Téléphone");phone.setInputType(InputType.TYPE_CLASS_PHONE);EditText request=new EditText(this);request.setHint("Votre demande");f.addView(name);f.addView(phone);f.addView(request);new AlertDialog.Builder(this).setTitle("Demander un devis").setView(f).setNegativeButton("Annuler",null).setPositiveButton("Envoyer",(d,w)->Toast.makeText(this,"Demande de devis envoyée.",Toast.LENGTH_LONG).show()).show();}
}
