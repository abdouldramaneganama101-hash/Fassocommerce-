package com.fassocommerce;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ProductStore {
    private static final String PREFS = "fasso_products";
    private static final String KEY = "items";
    private static final String AD_KEY = "advertising_uri";

    private ProductStore() {}

    public static JSONArray getProducts(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    public static void saveProducts(Context context, JSONArray products) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY, products.toString()).apply();
    }

    public static void addProduct(Context context, String name, String price, String stock,
                                   String description, String imageUri) throws Exception {
        JSONArray products = getProducts(context);
        JSONObject item = new JSONObject();
        item.put("id", System.currentTimeMillis());
        item.put("name", name);
        item.put("price", price);
        item.put("stock", stock);
        item.put("description", description);
        item.put("imageUri", imageUri == null ? "" : imageUri);
        JSONArray photos = new JSONArray();
        if (imageUri != null && !imageUri.isEmpty()) photos.put(imageUri);
        item.put("imageUris", photos);
        products.put(item);
        saveProducts(context, products);
    }

    public static void updateProduct(Context context, int index, String name, String price,
                                     String stock, String description, String imageUri) throws Exception {
        JSONArray products = getProducts(context);
        if (index < 0 || index >= products.length()) return;
        JSONObject item = products.getJSONObject(index);
        item.put("name", name);
        item.put("price", price);
        item.put("stock", stock);
        item.put("description", description);
        item.put("imageUri", imageUri == null ? "" : imageUri);
        saveProducts(context, products);
    }

    public static void addProduct(Context context, String name, String price, String stock,
                                   String description, JSONArray imageUris) throws Exception {
        JSONArray products = getProducts(context);
        JSONObject item = new JSONObject();
        item.put("id", System.currentTimeMillis());
        item.put("name", name); item.put("price", price); item.put("stock", stock);
        item.put("description", description);
        JSONArray photos = imageUris == null ? new JSONArray() : imageUris;
        item.put("imageUris", photos);
        item.put("imageUri", photos.length() > 0 ? photos.optString(0, "") : "");
        products.put(item); saveProducts(context, products);
    }

    public static void updateProduct(Context context, int index, String name, String price,
                                     String stock, String description, JSONArray imageUris) throws Exception {
        JSONArray products = getProducts(context);
        if (index < 0 || index >= products.length()) return;
        JSONObject item = products.getJSONObject(index);
        item.put("name", name); item.put("price", price); item.put("stock", stock);
        item.put("description", description);
        JSONArray photos = imageUris == null ? new JSONArray() : imageUris;
        item.put("imageUris", photos);
        item.put("imageUri", photos.length() > 0 ? photos.optString(0, "") : "");
        saveProducts(context, products);
    }

    public static void deleteProduct(Context context, int index) {
        JSONArray products = getProducts(context);
        if (index < 0 || index >= products.length()) return;
        products.remove(index);
        saveProducts(context, products);
    }

    public static String getAdvertisingUri(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(AD_KEY, "");
    }

    public static void setAdvertisingUri(Context context, String uri) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(AD_KEY, uri == null ? "" : uri).apply();
    }

    public static void clearAdvertising(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(AD_KEY).apply();
    }
}
